-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: internal-db.s41232.gridserver.com
-- Generation Time: Dec 14, 2011 at 09:51 AM
-- Server version: 5.1.55
-- PHP Version: 4.4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db41232_oddjob`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblActions`
--

DROP TABLE IF EXISTS `tblActions`;
CREATE TABLE IF NOT EXISTS `tblActions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `info` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tblActions`
--

INSERT INTO `tblActions` (`id`, `name`, `info`, `url`, `added`, `modified`) VALUES
(1, 'Install', 'Installed application request', '', '2011-09-26 21:17:59', '2011-09-26 22:11:51'),
(2, 'Perform', 'Perform job request', '', '2011-09-26 21:18:34', '2011-09-26 22:11:51'),
(3, 'Cancel', 'Cancel job request', '', '2011-09-26 21:18:47', '2011-09-26 22:11:51'),
(4, 'Complete', 'Complete job request', '', '2011-09-26 21:19:20', '2011-09-26 22:11:51'),
(5, 'Achieve', 'Achievement point request', '', '2011-09-26 21:19:35', '2011-09-26 22:11:51'),
(6, 'Like', 'Like Request', '', '2011-09-26 22:08:33', '2011-09-26 22:11:51'),
(7, 'Share', 'Sharing request', '', '2011-09-26 22:08:41', '2011-09-26 22:11:51'),
(8, 'Location', 'Location request', '', '2011-09-26 22:09:02', '2011-09-26 22:11:51'),
(9, 'Odd Wall', 'Offer wall', '', '2011-09-26 22:09:15', '2011-09-26 22:11:51'),
(10, 'Odd Likes', 'Like wall', '', '2011-09-26 22:09:25', '2011-09-26 22:11:51'),
(11, 'Submit', '', '', '2011-09-27 00:01:21', '2011-09-27 00:01:21'),
(12, 'Play', '', '', '2011-10-30 17:29:18', '2011-10-30 17:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `tblActionsObjects`
--

DROP TABLE IF EXISTS `tblActionsObjects`;
CREATE TABLE IF NOT EXISTS `tblActionsObjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tblActionsObjects`
--

INSERT INTO `tblActionsObjects` (`id`, `action_id`, `object_id`, `added`) VALUES
(1, 1, 1, '2011-09-26 23:54:44'),
(2, 1, 9, '2011-09-26 23:55:18'),
(3, 1, 10, '2011-09-26 23:55:24'),
(4, 2, 1, '2011-09-26 23:55:50'),
(5, 2, 9, '2011-09-26 23:56:08'),
(6, 2, 11, '2011-09-26 23:56:15'),
(7, 3, 1, '2011-09-26 23:56:32'),
(8, 3, 9, '2011-09-26 23:56:38'),
(9, 3, 11, '2011-09-26 23:56:45'),
(10, 4, 1, '2011-09-26 23:57:04'),
(11, 4, 9, '2011-09-26 23:57:12'),
(12, 4, 11, '2011-09-26 23:57:17'),
(13, 5, 1, '2011-09-26 23:57:30'),
(14, 5, 10, '2011-09-26 23:57:48'),
(15, 5, 9, '2011-09-26 23:57:59'),
(16, 6, 1, '2011-09-26 23:58:29'),
(17, 6, 9, '2011-09-26 23:58:35'),
(18, 6, 11, '2011-09-26 23:58:48'),
(19, 7, 1, '2011-09-26 23:59:23'),
(20, 7, 9, '2011-09-26 23:59:29'),
(21, 7, 11, '2011-09-26 23:59:35'),
(22, 8, 1, '2011-09-26 23:59:48'),
(23, 8, 9, '2011-09-26 23:59:53'),
(24, 8, 11, '2011-09-26 23:59:59'),
(25, 9, 8, '2011-09-27 00:00:26'),
(26, 10, 8, '2011-09-27 00:00:46'),
(27, 11, 1, '2011-09-27 00:01:40'),
(28, 11, 9, '2011-09-27 00:01:46'),
(29, 11, 11, '2011-09-27 00:01:54'),
(30, 1, 2, '2011-09-27 00:18:44'),
(31, 1, 3, '2011-09-27 00:18:50'),
(32, 2, 2, '2011-09-27 00:19:25'),
(33, 2, 3, '2011-09-27 00:19:31'),
(34, 3, 2, '2011-09-27 00:20:00'),
(35, 3, 3, '2011-09-27 00:20:08'),
(36, 3, 10, '2011-09-27 00:20:33'),
(37, 4, 2, '2011-09-27 00:21:11'),
(38, 4, 3, '2011-09-27 00:21:11'),
(39, 6, 2, '2011-09-27 00:21:49'),
(40, 6, 3, '2011-09-27 00:21:49'),
(41, 7, 2, '2011-09-27 00:22:08'),
(42, 7, 3, '2011-09-27 00:22:08'),
(43, 8, 2, '2011-09-27 00:22:32'),
(44, 8, 3, '2011-09-27 00:22:32'),
(45, 11, 1, '2011-09-27 00:25:09'),
(46, 11, 2, '2011-09-27 00:25:09'),
(47, 11, 3, '2011-09-27 00:25:39'),
(48, 11, 9, '2011-09-27 00:25:39'),
(49, 11, 11, '2011-09-27 00:25:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblAntedJobs`
--

DROP TABLE IF EXISTS `tblAntedJobs`;
CREATE TABLE IF NOT EXISTS `tblAntedJobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `terms` varchar(255) NOT NULL,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `object_id` int(11) NOT NULL DEFAULT '0',
  `app_id` int(11) NOT NULL DEFAULT '0',
  `amout` float NOT NULL DEFAULT '0',
  `longitude` float NOT NULL DEFAULT '0',
  `latitude` float NOT NULL DEFAULT '0',
  `age_min` int(11) NOT NULL DEFAULT '0',
  `age_max` int(11) NOT NULL DEFAULT '99',
  `sex` char(1) NOT NULL DEFAULT 'N',
  `friends` int(11) NOT NULL DEFAULT '0',
  `pts` int(11) NOT NULL DEFAULT '0',
  `pts_req` int(11) NOT NULL DEFAULT '0',
  `slots` int(11) NOT NULL DEFAULT '33',
  `edu_id` int(11) NOT NULL DEFAULT '0',
  `isActive` char(1) NOT NULL DEFAULT 'Y',
  `added` datetime NOT NULL,
  `expires` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `tblAntedJobs`
--

INSERT INTO `tblAntedJobs` (`id`, `type_id`, `title`, `info`, `terms`, `supplier_id`, `object_id`, `app_id`, `amout`, `longitude`, `latitude`, `age_min`, `age_max`, `sex`, `friends`, `pts`, `pts_req`, `slots`, `edu_id`, `isActive`, `added`, `expires`, `modified`) VALUES
(100, 1, 'Install Shoutflow for Free Heineken Beer', 'Install Shoutflow now for Free Beer at the Nut House in Palo Alto.', 'This application deal will expire in 4 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 19, 18, 0, 0, 0, 0, 99, 'N', 0, 25, 0, 30, 0, 'Y', '2011-10-17 11:03:37', '2011-10-17 11:30:39', '2011-10-30 21:38:03'),
(101, 1, 'Install Pet Hotel for Free Pocket Gem Credits now!', 'Install Pet Hotel for Free Pocket Gem Credits. This deal will last 3 days. ', 'This application deal will expire in 4 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 0, 23, 15, 0, 0, 0, 18, 35, 'N', 0, 0, 0, 30, 0, 'Y', '2011-10-30 20:36:02', '2011-10-30 20:36:02', '2011-10-30 21:39:59'),
(102, 1, 'Install Tiny Animals now and get Free Castleville Credits', 'Install Tiny Animals from TinyCo and receive Free Castleville Credits now.', 'This application deal will expire in 4 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 0, 8, 4, 0, 0, 0, 18, 25, 'N', 0, 0, 0, 33, 0, 'Y', '2011-10-30 20:38:53', '2011-10-30 20:38:53', '2011-10-30 21:41:01');

-- --------------------------------------------------------

--
-- Table structure for table `tblApps`
--

DROP TABLE IF EXISTS `tblApps`;
CREATE TABLE IF NOT EXISTS `tblApps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `info` varchar(255) NOT NULL,
  `itunes_id` int(11) NOT NULL,
  `youtube_id` varchar(255) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `tblApps`
--

INSERT INTO `tblApps` (`id`, `name`, `info`, `itunes_id`, `youtube_id`, `added`, `modified`) VALUES
(1, 'Words With Friends', '', 321916506, '8SnHh1ZnIxk', '2011-10-04 20:58:22', '2011-12-05 15:24:21'),
(2, 'Heineken App', '', 395515389, '3M8Dp7wGBe4', '2011-10-07 16:53:19', '2011-12-05 15:24:55'),
(3, 'Shadowgun', '', 440141669, 'YhA0cbu1BxI', '2011-10-07 16:53:35', '2011-12-05 15:25:17'),
(4, 'Tiny Animals', '', 407770970, 'i6buemjndvU', '2011-10-09 14:57:21', '2011-12-05 15:26:06'),
(5, 'Fab', '', 469422050, 'HXkRYtSKla8', '2011-10-25 00:55:25', '2011-12-05 15:26:51'),
(8, 'Assassin''s Creed', '', 313367811, 'jYSygJBPnG8', '2011-10-25 00:56:18', '2011-12-05 15:27:59'),
(9, 'Tiny Pets', '', 453294846, 'mXlC4efOyQc', '2011-10-25 00:56:49', '2011-12-05 15:28:22'),
(10, 'Scion', '', 337794066, '3kIaBMtV22c', '2011-10-25 00:57:00', '2011-12-05 15:28:52'),
(11, 'Puss in Boots', '', 473100476, 'T9LzF4B6k6k', '2011-10-25 00:57:17', '2011-12-05 15:29:28'),
(14, 'Spotify', '', 324684580, 'F0XF5NAoU90', '2011-10-25 00:57:56', '2011-12-05 15:30:14'),
(18, 'Shoutflow', '', 447279762, 'N9a4iJfXscY', '2011-10-30 21:36:38', '2011-12-05 15:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `tblChallenges`
--

DROP TABLE IF EXISTS `tblChallenges`;
CREATE TABLE IF NOT EXISTS `tblChallenges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `fb_id` varchar(255) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tblChallenges`
--

INSERT INTO `tblChallenges` (`id`, `type_id`, `job_id`, `fb_id`, `added`) VALUES
(3, 0, 4, '660042243', '2011-12-07 20:24:31'),
(6, 0, 3, '660042243', '2011-12-07 22:26:03'),
(5, 0, 3, '660042243', '2011-12-07 22:25:44'),
(7, 0, 3, '660042243', '2011-12-07 22:27:01'),
(8, 0, 3, '660042243', '2011-12-07 22:27:14'),
(9, 0, 3, '660042243', '2011-12-07 22:27:23'),
(10, 0, 3, '660042243', '2011-12-07 23:24:31'),
(11, 0, 3, '660042243', '2011-12-07 23:25:07'),
(12, 0, 3, '660042243', '2011-12-07 23:27:40'),
(13, 0, 3, '660042243', '2011-12-07 23:28:37'),
(14, 0, 3, '660042243', '2011-12-07 23:33:44'),
(15, 0, 3, '660042243', '2011-12-08 00:06:27'),
(16, 0, 4, '660042243', '2011-12-08 00:14:31'),
(17, 0, 4, '660042243', '2011-12-08 00:15:17'),
(20, 0, 4, '660042243', '2011-12-10 20:38:10'),
(19, 0, 3, '660042243', '2011-12-08 15:40:10'),
(21, 0, 3, '660042243', '2011-12-10 22:03:41'),
(22, 2, 4, '660042243', '2011-12-11 12:13:09'),
(23, 2, 4, '660042243', '2011-12-11 15:52:26'),
(24, 3, 4, '660042243', '2011-12-11 16:05:17'),
(25, 0, 0, '0', '2011-12-13 11:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `tblChallengeTypes`
--

DROP TABLE IF EXISTS `tblChallengeTypes`;
CREATE TABLE IF NOT EXISTS `tblChallengeTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tblChallengeTypes`
--

INSERT INTO `tblChallengeTypes` (`id`, `name`, `info`, `added`, `modified`) VALUES
(1, 'High Score', '', '2011-12-11 11:57:36', '2011-12-11 11:57:36'),
(2, 'Co-op', '', '2011-12-11 11:58:49', '2011-12-11 11:58:49'),
(3, '1-on-1', '', '2011-12-11 11:58:26', '2011-12-11 11:58:26');

-- --------------------------------------------------------

--
-- Table structure for table `tblEducationTypes`
--

DROP TABLE IF EXISTS `tblEducationTypes`;
CREATE TABLE IF NOT EXISTS `tblEducationTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tblEducationTypes`
--

INSERT INTO `tblEducationTypes` (`id`, `name`, `added`, `modified`) VALUES
(1, 'High School', '2011-09-16 12:37:08', '2011-09-16 12:37:08'),
(2, 'College', '2011-09-16 12:37:40', '2011-09-16 12:37:40');

-- --------------------------------------------------------

--
-- Table structure for table `tblImages`
--

DROP TABLE IF EXISTS `tblImages`;
CREATE TABLE IF NOT EXISTS `tblImages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL,
  `info` varchar(128) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=105 ;

--
-- Dumping data for table `tblImages`
--

INSERT INTO `tblImages` (`id`, `type_id`, `url`, `info`, `added`, `modified`) VALUES
(93, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tinycoIcon_fb.png', '', '2011-10-30 20:51:45', '2011-10-30 20:51:45'),
(92, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tinycoIcon.png', '', '2011-10-30 20:51:33', '2011-10-30 20:51:33'),
(91, 7, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tinycoFeature_sm.png', '', '2011-10-30 20:51:19', '2011-10-30 20:51:19'),
(90, 6, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tinycoFeature_lg.png', '', '2011-10-30 20:50:59', '2011-10-30 20:50:59'),
(89, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tapzooIcon_fb.png', '', '2011-10-30 20:49:55', '2011-10-30 20:49:55'),
(88, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tapzooIcon.png', '', '2011-10-30 20:49:42', '2011-10-30 20:49:42'),
(87, 7, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tapzooFeature_sm.png', '', '2011-10-30 20:49:22', '2011-10-30 20:49:22'),
(86, 6, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/tapzooFeature_lg.png', '', '2011-10-30 20:48:53', '2011-10-30 20:48:53'),
(85, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/heinekenIcon_fb.png', '', '2011-10-30 20:46:27', '2011-10-30 20:46:27'),
(84, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/heinekenIcon.png', '', '2011-10-30 20:45:59', '2011-10-30 20:45:59'),
(83, 7, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/heinekenFeature_sm.png', '', '2011-10-30 20:45:22', '2011-10-30 20:45:22'),
(82, 6, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/heinekenFeature_lg.png', '', '2011-10-30 20:44:33', '2011-10-30 20:44:33'),
(81, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/virginIcon_fb.png', '', '2011-10-30 20:15:09', '2011-10-30 20:15:09'),
(80, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/virginIcon.png', '', '2011-10-30 20:14:54', '2011-10-30 20:14:54'),
(79, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/virginHeader.png', '', '2011-10-30 20:14:40', '2011-10-30 20:14:40'),
(78, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/smurfsIcon_fb.png', '', '2011-10-30 20:13:39', '2011-10-30 20:13:39'),
(77, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/smurfsIcon.png', '', '2011-10-30 20:13:25', '2011-10-30 20:13:25'),
(76, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/smurfsHeader.png', '', '2011-10-30 20:13:11', '2011-10-30 20:13:11'),
(75, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/livingsocIcon_fb.png', '', '2011-10-30 20:12:04', '2011-10-30 20:12:04'),
(74, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/livingsocIcon.png', '', '2011-10-30 20:11:50', '2011-10-30 20:11:50'),
(73, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/livingsocHeader.png', '', '2011-10-30 20:11:35', '2011-10-30 20:11:35'),
(72, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/fabIcon_fb.png', '', '2011-10-30 20:10:39', '2011-10-30 20:10:39'),
(71, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/fabIcon.png', '', '2011-10-30 20:10:20', '2011-10-30 20:10:20'),
(70, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/fabHeader.png', '', '2011-10-30 20:10:04', '2011-10-30 20:10:04'),
(104, 8, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/bag_with_zr_mug.jpg', '', '2011-12-10 13:11:54', '2011-12-10 13:11:54'),
(66, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/spotifyIcon_fb.png', '', '2011-10-30 19:00:43', '2011-10-30 19:00:45'),
(65, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/spotifyIcon.png', '', '2011-10-30 19:00:22', '2011-10-30 19:00:22'),
(64, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/spotifyHeader.png', '', '2011-10-30 18:59:59', '2011-10-30 18:59:59'),
(60, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/bugvillIcon_fb.png', '', '2011-10-30 18:54:14', '2011-10-30 18:59:03'),
(59, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/bugvillIcon.png', '', '2011-10-30 18:53:59', '2011-10-30 18:53:59'),
(58, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/bugvillHeader.png', '', '2011-10-30 18:53:38', '2011-10-30 18:53:38'),
(57, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/pussinbootsIcon_fb.png', '', '2011-10-30 18:50:06', '2011-10-30 18:59:09'),
(56, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/pussinbootsIcon.png', '', '0000-00-00 00:00:00', '2011-10-30 18:48:21'),
(55, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/pussinbootsHeader.png', '', '2011-10-30 18:48:21', '2011-10-30 18:48:21'),
(54, 4, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/acIcon_fb.png', '', '2011-10-30 18:37:47', '2011-10-30 18:59:14'),
(52, 2, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/acHeader.png', '', '2011-10-30 17:59:50', '2011-10-30 17:59:50'),
(53, 1, 'http://dev.gullinbursti.cc/projs/oddjob/app/images/acIcon.png', '', '2011-10-30 18:20:06', '2011-10-30 18:20:09');

-- --------------------------------------------------------

--
-- Table structure for table `tblImageTypes`
--

DROP TABLE IF EXISTS `tblImageTypes`;
CREATE TABLE IF NOT EXISTS `tblImageTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tblImageTypes`
--

INSERT INTO `tblImageTypes` (`id`, `name`, `added`, `modified`) VALUES
(1, 'Icon', '2011-09-17 20:03:06', '2011-09-17 20:03:10'),
(2, 'List', '2011-09-17 20:03:13', '2011-09-17 20:03:42'),
(3, 'Detail', '2011-09-17 20:03:34', '2011-09-17 20:03:40'),
(4, 'FB App', '2011-10-19 18:55:36', '2011-10-19 18:55:49'),
(5, 'FB Ico', '2011-10-19 18:55:44', '2011-10-19 18:55:49'),
(6, 'Featured Main', '2011-10-20 18:54:00', '2011-10-20 18:54:10'),
(7, 'Featured Sub', '2011-10-20 18:54:07', '2011-10-20 18:54:10'),
(8, 'Merchant', '2011-12-10 12:55:25', '2011-12-10 12:55:25');

-- --------------------------------------------------------

--
-- Table structure for table `tblInvites`
--

DROP TABLE IF EXISTS `tblInvites`;
CREATE TABLE IF NOT EXISTS `tblInvites` (
  `id` int(11) NOT NULL,
  `fb_id` varchar(255) NOT NULL,
  `friend_id` varchar(255) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblInvites`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblJobChallengers`
--

DROP TABLE IF EXISTS `tblJobChallengers`;
CREATE TABLE IF NOT EXISTS `tblJobChallengers` (
  `challenge_id` int(11) NOT NULL,
  `fb_id` varchar(255) NOT NULL,
  PRIMARY KEY (`challenge_id`,`fb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblJobChallengers`
--

INSERT INTO `tblJobChallengers` (`challenge_id`, `fb_id`) VALUES
(3, '1032756544'),
(3, '1274248396'),
(3, '682777912'),
(3, '704056139'),
(3, '727765903'),
(5, '100000356712181'),
(5, '100001354400017'),
(5, '5006139'),
(5, '637604444'),
(6, '100000356712181'),
(6, '100001354400017'),
(6, '5006139'),
(6, '637604444'),
(7, '100000356712181'),
(7, '100001354400017'),
(7, '5006139'),
(7, '637604444'),
(8, '100000356712181'),
(8, '100001354400017'),
(8, '5006139'),
(8, '637604444'),
(9, '1372009399'),
(9, '5005562'),
(9, '5139464'),
(9, '704056139'),
(9, '706145610'),
(10, '1490253135,1754360619'),
(11, '5139464,1133930792'),
(12, '1'),
(13, '1'),
(14, '1265881868'),
(14, '1425866532'),
(14, '60714365'),
(14, '8368580'),
(15, '1415075411'),
(15, '18001690'),
(15, '18003227'),
(15, '624935030'),
(15, '653931435'),
(16, '1069521641'),
(16, '1754360619'),
(16, '768109377'),
(17, '100002902642066'),
(17, '5006139'),
(19, '144902078'),
(19, '1529436474'),
(19, '1587500910'),
(19, '18002134'),
(19, '819307'),
(20, '1'),
(21, '100000385077577'),
(21, '18003227'),
(21, '522757742'),
(21, '669208481'),
(22, '18000035'),
(22, '2018193'),
(23, '1587500910'),
(23, '821393635'),
(24, '643037844'),
(24, '692416261');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobMapPts`
--

DROP TABLE IF EXISTS `tblJobMapPts`;
CREATE TABLE IF NOT EXISTS `tblJobMapPts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `zip` varchar(64) NOT NULL,
  `longitude` float NOT NULL DEFAULT '0',
  `latitude` float NOT NULL DEFAULT '0',
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblJobMapPts`
--

INSERT INTO `tblJobMapPts` (`id`, `job_id`, `name`, `address`, `city`, `zip`, `longitude`, `latitude`, `added`, `modified`) VALUES
(1, 1, 'Featured I', '', '', '', -122.09, 37.399, '2011-10-20 00:00:00', '2011-10-20 19:10:01'),
(2, 2, 'Job I', '', '', '', -122.19, 37.46, '2011-10-20 19:10:41', '2011-10-20 19:10:41'),
(3, 3, 'Job II', '', '', '', -122.3, 37.44, '2011-10-20 19:11:35', '2011-10-20 19:11:35'),
(4, 4, 'Job III', '', '', '', -122, 37.3, '2011-10-20 19:11:35', '2011-10-20 19:11:35');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobRatings`
--

DROP TABLE IF EXISTS `tblJobRatings`;
CREATE TABLE IF NOT EXISTS `tblJobRatings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `fb_id` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `comment` text NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tblJobRatings`
--

INSERT INTO `tblJobRatings` (`id`, `job_id`, `fb_id`, `score`, `comment`, `added`) VALUES
(1, 2, '660042243', 1, 'sux ass', '2011-12-05 23:46:25'),
(2, 2, '660042243', 2, 'biggins', '2011-12-05 23:46:33'),
(3, 2, '660042243', 5, 'derp', '2011-12-05 23:41:00'),
(16, 1, '660042243', 1, '', '2011-12-10 16:00:34'),
(6, 1, '660042243', 4, '', '2011-12-06 20:47:58'),
(7, 5, '660042243', 2, '', '2011-12-06 20:49:06'),
(8, 6, '660042243', 4, '', '2011-12-06 20:49:22'),
(9, 7, '660042243', 1, '', '2011-12-06 20:50:31'),
(10, 6, '660042243', 1, '', '2011-12-06 20:50:45'),
(11, 1, '660042243', 2, '', '2011-12-06 22:48:48'),
(15, 1, '660042243', 5, '', '2011-12-08 00:15:51'),
(13, 1, '660042243', 3, '', '2011-12-06 23:55:26'),
(17, 1, '660042243', 4, '', '2011-12-10 19:37:56'),
(18, 1, '660042243', 4, '', '2011-12-10 22:01:11'),
(19, 1, '660042243', 3, '', '2011-12-11 15:51:45'),
(20, 1, '660042243', 4, '', '2011-12-11 16:27:27'),
(21, 1, '660042243', 4, '', '2011-12-13 13:35:03');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobs`
--

DROP TABLE IF EXISTS `tblJobs`;
CREATE TABLE IF NOT EXISTS `tblJobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(128) NOT NULL DEFAULT '0',
  `title` varchar(128) NOT NULL,
  `info` varchar(256) NOT NULL,
  `terms` varchar(255) NOT NULL,
  `merchant_id` int(128) NOT NULL DEFAULT '0',
  `object_id` int(11) NOT NULL DEFAULT '0',
  `app_id` int(11) NOT NULL DEFAULT '0',
  `amount` float NOT NULL DEFAULT '0',
  `longitude` float NOT NULL,
  `latitude` float NOT NULL,
  `age_min` int(11) NOT NULL DEFAULT '0',
  `age_max` int(11) NOT NULL DEFAULT '0',
  `sex` char(1) NOT NULL DEFAULT 'N',
  `friends` int(11) NOT NULL DEFAULT '0',
  `pts` int(128) NOT NULL DEFAULT '0',
  `pts_req` int(128) NOT NULL DEFAULT '0',
  `slots` int(128) NOT NULL DEFAULT '0',
  `edu_id` int(11) NOT NULL DEFAULT '1',
  `isActive` char(1) NOT NULL DEFAULT 'Y',
  `added` datetime NOT NULL,
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tblJobs`
--

INSERT INTO `tblJobs` (`id`, `type_id`, `title`, `info`, `terms`, `merchant_id`, `object_id`, `app_id`, `amount`, `longitude`, `latitude`, `age_min`, `age_max`, `sex`, `friends`, `pts`, `pts_req`, `slots`, `edu_id`, `isActive`, `added`, `expires`, `modified`) VALUES
(1, 10, 'Want FREE Movie Tix?', 'Review Puss in Boots for a Free Movie Ticket to Puss and Boots in Palo Alto, right now!', 'This application deal will expire in 3 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 17, 11, 0, -122.138, 37.4292, 25, 40, 'N', 30, 25, 0, 34, 0, 'Y', '2011-10-30 17:02:59', '2011-10-26 16:15:59', '2011-12-13 18:01:00'),
(2, 9, '50% off A-Creed', 'Watch Assassins Creed Trailer and get 50% off the paid version', 'This application deal will expire in 3 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 4, 8, 0, -122.138, 37.4292, 13, 26, 'N', 45, 3, 0, 84, 1, 'Y', '2011-10-30 17:03:36', '2011-10-22 16:16:44', '2011-12-13 18:05:11'),
(3, 11, 'Want FREE Bug Village Bucks?', 'Install and Play Bug Village now and get 1000 Free Bug Village Bucks', 'This application deal will expire in 3 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 10, 3, 0, -122.138, 37.4292, 13, 26, 'N', 20, 30, 0, 37, 1, 'Y', '2011-10-30 17:05:00', '2011-10-24 16:17:25', '2011-12-13 17:59:52'),
(4, 11, '10% off NIKEiD shoes', 'Challenge a friend for Kobe VII and get 10% NIKEiD in Palo Alto', 'This application deal will expire in 3 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 43, 1, 0, -122.138, 37.4292, 13, 26, 'N', 0, 0, 0, 23, 1, 'Y', '2011-10-09 14:17:31', '0000-00-00 00:00:00', '2011-12-13 19:11:48'),
(5, 10, 'Want Free Spotify?', 'Review Spotify on iOS and get 2 months Free now.', 'This application deal will expire in 3 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 22, 14, 0, -86.0856, 35.4733, 13, 34, 'N', 0, 0, 0, 21, 1, 'Y', '2011-10-23 12:57:34', '0000-00-00 00:00:00', '2011-12-10 13:13:16'),
(6, 10, 'Free Movie Tickets', 'Play Puss In Boots and Get FREE Movie Tickets!', 'This application deal will expire in 3 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 17, 11, 0, -122.138, 37.4292, 13, 35, 'N', 0, 0, 0, 40, 1, 'Y', '2011-10-23 13:46:44', '0000-00-00 00:00:00', '2011-12-13 18:20:25'),
(7, 10, 'Install Fab''s iPad App, 10% Off', 'Get 10% off for reviewing Fab''s new iPad application.', 'This application deal will expire in 3 days. To use the application deal you must have a Facebook account and allow access to Facebook Credits. Zynga Poker is copyright and trademarked to Zynga.', 1, 18, 5, 0, -122.138, 37.4292, 18, 30, 'N', 0, 0, 0, 4, 16, 'Y', '2011-10-23 14:01:27', '0000-00-00 00:00:00', '2011-12-13 18:13:22');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobsImages`
--

DROP TABLE IF EXISTS `tblJobsImages`;
CREATE TABLE IF NOT EXISTS `tblJobsImages` (
  `job_id` int(11) NOT NULL DEFAULT '0',
  `image_id` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`job_id`,`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblJobsImages`
--

INSERT INTO `tblJobsImages` (`job_id`, `image_id`, `sort`) VALUES
(101, 88, 0),
(101, 87, 0),
(101, 86, 0),
(100, 85, 0),
(100, 84, 0),
(100, 83, 0),
(100, 82, 0),
(13, 81, 0),
(13, 80, 0),
(13, 79, 0),
(10, 78, 0),
(10, 77, 0),
(10, 76, 0),
(14, 75, 0),
(14, 74, 0),
(14, 73, 0),
(7, 72, 0),
(7, 71, 0),
(7, 70, 0),
(11, 66, 0),
(11, 65, 0),
(11, 64, 0),
(5, 65, 0),
(5, 66, 0),
(5, 64, 0),
(4, 63, 0),
(4, 62, 0),
(4, 61, 0),
(16, 60, 0),
(16, 59, 0),
(16, 58, 0),
(3, 60, 0),
(3, 59, 0),
(3, 58, 0),
(6, 57, 0),
(6, 56, 0),
(6, 55, 0),
(1, 57, 0),
(1, 55, 0),
(1, 56, 0),
(15, 54, 0),
(2, 54, 0),
(2, 52, 0),
(2, 53, 0),
(15, 52, 0),
(15, 53, 0),
(101, 89, 0),
(102, 90, 0),
(102, 91, 0),
(102, 92, 0),
(102, 93, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblJobsLikes`
--

DROP TABLE IF EXISTS `tblJobsLikes`;
CREATE TABLE IF NOT EXISTS `tblJobsLikes` (
  `job_id` int(11) NOT NULL,
  `like_id` int(11) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`job_id`,`like_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblJobsLikes`
--

INSERT INTO `tblJobsLikes` (`job_id`, `like_id`, `added`) VALUES
(2, 9, '2011-12-05 20:33:01'),
(2, 11, '2011-12-05 20:33:01'),
(2, 12, '2011-12-05 20:33:08'),
(4, 14, '2011-12-05 20:34:54'),
(4, 15, '2011-12-05 20:34:54'),
(4, 16, '2011-12-05 20:35:02'),
(3, 11, '2011-12-05 20:35:38'),
(3, 12, '2011-12-05 20:35:38'),
(3, 9, '2011-12-05 20:35:45'),
(5, 3, '2011-12-05 20:36:15'),
(5, 17, '2011-12-05 20:36:35'),
(6, 18, '2011-12-05 20:37:26'),
(6, 9, '2011-12-05 20:37:26'),
(6, 11, '2011-12-05 20:37:40'),
(6, 12, '2011-12-05 20:37:40'),
(7, 11, '2011-12-05 20:38:05'),
(7, 6, '2011-12-05 20:38:05');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobsLocalities`
--

DROP TABLE IF EXISTS `tblJobsLocalities`;
CREATE TABLE IF NOT EXISTS `tblJobsLocalities` (
  `job_id` int(11) NOT NULL,
  `locality_id` int(11) NOT NULL,
  PRIMARY KEY (`job_id`,`locality_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblJobsLocalities`
--

INSERT INTO `tblJobsLocalities` (`job_id`, `locality_id`) VALUES
(1, 2),
(1, 5),
(2, 2),
(2, 3),
(2, 4),
(3, 1),
(3, 2),
(3, 3),
(3, 4),
(3, 6),
(3, 7),
(3, 8),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(6, 4),
(6, 6),
(7, 3),
(7, 5),
(9, 1),
(9, 2),
(9, 3),
(9, 4),
(9, 5),
(9, 6),
(10, 2),
(10, 3),
(10, 5),
(10, 6),
(11, 1),
(11, 2),
(11, 3),
(11, 4),
(11, 5),
(11, 6),
(12, 1),
(12, 2),
(14, 1),
(14, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblJobStatusTypes`
--

DROP TABLE IF EXISTS `tblJobStatusTypes`;
CREATE TABLE IF NOT EXISTS `tblJobStatusTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `info` varchar(256) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tblJobStatusTypes`
--

INSERT INTO `tblJobStatusTypes` (`id`, `name`, `info`, `added`, `modified`) VALUES
(1, 'Open', '', '2011-09-18 23:07:42', '2011-09-18 23:08:02'),
(2, 'Full', '', '2011-09-18 23:07:46', '2011-09-18 23:08:07'),
(3, 'Expired', '', '2011-09-18 23:07:49', '2011-09-18 23:08:09'),
(4, 'Pending', '', '2011-09-18 23:07:51', '2011-09-18 23:08:12'),
(5, 'Dropped', '', '2011-09-18 23:07:54', '2011-09-19 21:13:24'),
(6, 'Active', '', '2011-09-18 23:07:56', '2011-09-19 21:13:27'),
(7, 'Completed', '', '2011-09-18 23:07:59', '2011-09-19 21:13:29'),
(8, 'Canceled', '', '2011-09-19 21:13:37', '2011-09-19 21:13:41');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobTags`
--

DROP TABLE IF EXISTS `tblJobTags`;
CREATE TABLE IF NOT EXISTS `tblJobTags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `info` varchar(256) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblJobTags`
--

INSERT INTO `tblJobTags` (`id`, `name`, `info`, `added`, `modified`) VALUES
(1, 'Tag I', '', '2011-09-17 10:35:41', '2011-09-18 23:02:49');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobTypes`
--

DROP TABLE IF EXISTS `tblJobTypes`;
CREATE TABLE IF NOT EXISTS `tblJobTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `info` varchar(256) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tblJobTypes`
--

INSERT INTO `tblJobTypes` (`id`, `name`, `info`, `added`, `modified`) VALUES
(1, 'Install', 'Install App', '2011-09-16 16:26:19', '2011-10-23 01:11:43'),
(2, 'Share', 'Share App', '2011-09-16 16:27:12', '2011-10-23 01:11:43'),
(3, 'Like', 'Like App', '2011-09-16 16:28:27', '2011-10-23 01:11:43'),
(9, 'View', 'Listen / View Media', '2011-09-26 22:00:45', '2011-12-08 23:38:42'),
(10, 'Recommend', 'Recommend an app to friends', '2011-10-30 17:07:45', '2011-12-10 16:01:30'),
(11, 'Challenge', 'Challenge a friend to an installed game', '2011-12-06 13:09:35', '2011-12-07 00:21:21');

-- --------------------------------------------------------

--
-- Table structure for table `tblJobWatches`
--

DROP TABLE IF EXISTS `tblJobWatches`;
CREATE TABLE IF NOT EXISTS `tblJobWatches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) NOT NULL,
  `fb_id` varchar(255) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tblJobWatches`
--

INSERT INTO `tblJobWatches` (`id`, `job_id`, `fb_id`, `added`) VALUES
(1, 2, '660042243', '2011-12-06 12:38:43'),
(2, 2, '660042243', '2011-12-06 21:57:52'),
(3, 2, '660042243', '2011-12-06 22:55:42'),
(4, 2, '660042243', '2011-12-06 22:56:19'),
(5, 2, '660042243', '2011-12-06 22:58:05'),
(6, 2, '660042243', '2011-12-06 23:38:35'),
(7, 2, '660042243', '2011-12-08 00:16:57'),
(8, 2, '660042243', '2011-12-08 21:43:00'),
(9, 2, '660042243', '2011-12-10 20:58:16'),
(10, 2, '660042243', '2011-12-10 21:42:39'),
(11, 2, '660042243', '2011-12-10 22:02:46'),
(12, 2, '660042243', '2011-12-11 12:46:24'),
(13, 2, '660042243', '2011-12-11 12:47:56'),
(14, 2, '660042243', '2011-12-11 12:48:15'),
(15, 2, '660042243', '2011-12-11 13:06:00'),
(16, 2, '660042243', '2011-12-11 15:52:52'),
(17, 2, '660042243', '2011-12-11 16:23:27'),
(18, 2, '660042243', '2011-12-13 13:33:13');

-- --------------------------------------------------------

--
-- Table structure for table `tblLikes`
--

DROP TABLE IF EXISTS `tblLikes`;
CREATE TABLE IF NOT EXISTS `tblLikes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(25) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tblLikes`
--

INSERT INTO `tblLikes` (`id`, `fb_id`, `name`, `added`, `modified`) VALUES
(1, '0', 'NASA TV', '2011-12-05 20:28:07', '2011-12-05 20:30:13'),
(2, '0', 'Cake', '2011-12-05 20:28:07', '2011-12-05 20:28:07'),
(3, '0', 'Technology', '2011-12-05 20:28:34', '2011-12-05 20:28:34'),
(4, '0', 'Beaches', '2011-12-05 20:28:34', '2011-12-05 20:28:34'),
(5, '0', 'DeLorean', '2011-12-05 20:28:56', '2011-12-05 20:28:56'),
(6, '0', 'Design', '2011-12-05 20:28:56', '2011-12-05 20:28:56'),
(7, '0', 'Jersey Shore', '2011-12-05 20:29:19', '2011-12-05 20:29:19'),
(8, '0', 'CSI: Miami', '2011-12-05 20:29:19', '2011-12-05 20:29:19'),
(9, '0', 'Apple', '2011-12-05 20:29:42', '2011-12-05 20:29:42'),
(10, '0', 'Windows XP', '2011-12-05 20:29:42', '2011-12-05 20:29:42'),
(11, '0', 'iOS', '0000-00-00 00:00:00', '2011-12-05 20:32:40'),
(12, '0', 'Gaming', '0000-00-00 00:00:00', '2011-12-05 20:32:40'),
(13, '0', 'Travel', '2011-12-05 20:33:28', '2011-12-05 20:33:28'),
(14, '0', 'NIKE', '2011-12-05 20:33:56', '2011-12-05 20:33:56'),
(15, '0', 'Shoes', '2011-12-05 20:33:56', '2011-12-05 20:33:56'),
(16, '0', 'Athletics', '2011-12-05 20:34:07', '2011-12-05 20:34:07'),
(17, '0', 'Music', '2011-12-05 20:36:31', '2011-12-05 20:36:31'),
(18, '0', 'Movies', '2011-12-05 20:37:00', '2011-12-05 20:37:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblLocalities`
--

DROP TABLE IF EXISTS `tblLocalities`;
CREATE TABLE IF NOT EXISTS `tblLocalities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '',
  `info` varchar(256) NOT NULL,
  `state` char(2) NOT NULL DEFAULT '',
  `zip` varchar(128) NOT NULL DEFAULT '',
  `longitude` float NOT NULL DEFAULT '0',
  `latitude` float NOT NULL DEFAULT '0',
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tblLocalities`
--

INSERT INTO `tblLocalities` (`id`, `name`, `info`, `state`, `zip`, `longitude`, `latitude`, `added`, `modified`) VALUES
(1, 'San Francisco', '', 'CA', '0', 0, 0, '2011-09-18 22:09:18', '2011-09-18 23:03:03'),
(2, 'Los Angeles', '', 'CA', '0', 0, 0, '2011-09-18 22:10:01', '2011-09-18 23:03:04'),
(3, 'Miami', '', 'FL', '0', 0, 0, '2011-09-18 22:10:08', '2011-09-18 23:03:05'),
(4, 'New York', '', 'NY', '0', 0, 0, '2011-09-18 22:10:28', '2011-09-18 23:03:06'),
(5, 'Arizona', '', 'AZ', '0', 0, 0, '2011-09-21 21:18:27', '2011-09-21 21:18:47'),
(6, 'Austin', '', 'TX', '0', 0, 0, '2011-09-21 21:22:50', '2011-09-21 21:22:55'),
(7, 'Seattle', '', 'WA', '0', 0, 0, '2011-09-21 21:23:13', '2011-09-21 21:23:20'),
(8, 'Chicago', '', 'IL', '0', 0, 0, '2011-09-21 21:23:32', '2011-09-21 21:23:35');

-- --------------------------------------------------------

--
-- Table structure for table `tblMerchants`
--

DROP TABLE IF EXISTS `tblMerchants`;
CREATE TABLE IF NOT EXISTS `tblMerchants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `address` varchar(256) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` char(2) NOT NULL,
  `zip` char(5) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tblMerchants`
--

INSERT INTO `tblMerchants` (`id`, `name`, `address`, `city`, `state`, `zip`, `phone`, `added`, `modified`) VALUES
(1, 'Zombie Runner', '1300 Washington Street', 'Calistoga', 'CA', '94515', '', '2011-09-18 22:54:13', '2011-12-10 13:02:56'),
(2, 'The Nuthouse', '', '', '', '', '', '2011-09-18 22:55:13', '2011-09-18 22:55:22'),
(3, 'Virgin America', '', '', '', '', '', '2011-09-18 22:55:16', '2011-09-18 22:55:24'),
(4, 'Indie Dev', '', '', '', '', '', '2011-09-18 22:55:19', '2011-09-18 22:55:27'),
(6, 'Heineken Beer', '', '', '', '', '', '2011-10-09 20:28:30', '2011-10-09 20:29:17'),
(7, 'Reel Steel Tickets', '', '', '', '', '', '0000-00-00 00:00:00', '2011-10-09 20:29:17'),
(8, 'CityVille City Cash', '', '', '', '', '', '2011-10-09 20:29:41', '2011-10-09 20:29:45'),
(9, 'Bonnaro Tickets', '', '', '', '', '', '2011-10-23 13:10:33', '2011-10-23 13:10:37');

-- --------------------------------------------------------

--
-- Table structure for table `tblMerchantsImages`
--

DROP TABLE IF EXISTS `tblMerchantsImages`;
CREATE TABLE IF NOT EXISTS `tblMerchantsImages` (
  `merchant_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  PRIMARY KEY (`merchant_id`,`image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblMerchantsImages`
--

INSERT INTO `tblMerchantsImages` (`merchant_id`, `image_id`) VALUES
(1, 104);

-- --------------------------------------------------------

--
-- Table structure for table `tblObjects`
--

DROP TABLE IF EXISTS `tblObjects`;
CREATE TABLE IF NOT EXISTS `tblObjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `display` varchar(255) NOT NULL,
  `info` varchar(256) NOT NULL,
  `url` varchar(256) NOT NULL,
  `active` char(1) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `tblObjects`
--

INSERT INTO `tblObjects` (`id`, `name`, `display`, `info`, `url`, `active`, `added`, `modified`) VALUES
(1, 'odd_job', 'Odd Job', '', '', 'Y', '2011-09-26 22:15:29', '2011-09-26 22:15:29'),
(2, 'budweiser', 'Budweiser', '', '', 'N', '2011-09-26 22:15:41', '2011-09-26 22:15:41'),
(3, 'instagram', 'Instagram', '', '', 'N', '2011-09-26 22:16:11', '2011-09-26 22:16:11'),
(4, 'assassins_creed', 'Assassin''s Creed', '', '', 'Y', '2011-09-26 22:16:26', '2011-09-26 22:16:26'),
(6, 'bug_village', 'Bug Village', '', '', 'Y', '2011-09-26 22:18:08', '2011-09-26 22:18:08'),
(7, 'smurfs_village', 'Smurf''s Village', '', '', 'Y', '2011-09-26 22:18:27', '2011-09-26 22:18:27'),
(8, 'tiny_animals', 'Tiny Animals', '', '', 'Y', '2011-09-26 22:18:37', '2011-09-26 22:18:37'),
(9, 'w_hotel', 'W Hotel', '', '', 'N', '2011-09-26 22:18:47', '2011-09-26 22:18:47'),
(10, 'shadowgun', 'Shadowgun', '', '', 'N', '2011-09-26 22:19:01', '2011-09-26 22:19:01'),
(11, 'zynga', 'Zynga', '', '', 'N', '2011-09-26 22:19:12', '2011-09-26 22:19:12'),
(12, 'pepsi', 'Pepsi', '', '', 'N', '2011-09-29 19:51:00', '2011-09-29 19:51:04'),
(13, 'heineken_beer', 'Heineken', '', '', 'N', '2011-10-09 21:30:24', '2011-10-09 21:30:24'),
(14, 'reel_steel_tickets', 'Reel Steel Tickets', '', '', 'Y', '2011-10-09 21:30:51', '2011-10-09 21:30:54'),
(15, 'cityville_city_cash', 'CityVille City Cash', '', '', 'Y', '2011-10-09 21:30:51', '2011-10-09 21:31:38'),
(16, 'scion', 'Scion', '', '', 'Y', '2011-10-23 12:58:16', '2011-10-23 12:58:19'),
(17, 'puss_in_boots', 'Puss in Boots', '', '', 'Y', '2011-10-23 13:47:51', '2011-10-23 13:47:59'),
(18, 'fab', 'Fab', '', '', 'Y', '2011-10-23 14:00:23', '2011-10-23 14:00:32'),
(19, 'shoutflow', 'Shoutflow', '', '', 'Y', '2011-10-23 14:05:33', '2011-10-23 14:05:36'),
(43, 'words_with_friends', 'Words With Friends', '', '', 'Y', '2011-12-07 20:22:44', '2011-12-07 20:22:44'),
(22, 'spotify', 'Spotify', '', '', 'Y', '2011-10-23 14:26:11', '2011-10-23 14:26:16'),
(23, 'tap_zoo', 'Tap Zoo', '', '', 'Y', '2011-10-23 14:29:56', '2011-10-23 14:30:00'),
(24, 'virgin_america', 'Virgin America', '', '', 'Y', '2011-10-23 14:42:08', '2011-10-23 14:42:11'),
(25, 'living_social', 'Living Social', '', '', 'Y', '2011-10-23 14:46:20', '2011-10-23 14:46:23');

-- --------------------------------------------------------

--
-- Table structure for table `tblRegions`
--

DROP TABLE IF EXISTS `tblRegions`;
CREATE TABLE IF NOT EXISTS `tblRegions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `info` varchar(256) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `tblRegions`
--

INSERT INTO `tblRegions` (`id`, `name`, `info`, `added`, `modified`) VALUES
(1, 'Northeast', '', '2011-09-17 19:50:03', '2011-09-17 19:50:30'),
(2, 'Mid Atlantic', '', '2011-09-17 19:50:12', '2011-09-17 19:50:37'),
(3, 'South', '', '2011-09-17 19:50:42', '2011-09-17 19:50:46'),
(4, 'Midwest', '', '2011-09-17 19:51:03', '2011-09-17 19:51:17'),
(5, 'Southwest', '', '2011-09-17 19:51:10', '2011-09-17 19:51:14'),
(6, 'Northwest', '', '2011-09-17 19:51:36', '2011-09-17 19:51:40'),
(7, 'Europe', '', '2011-09-18 23:11:44', '2011-09-18 23:12:18'),
(8, 'Australia', '', '2011-09-18 23:11:48', '2011-09-18 23:12:15'),
(9, 'Africa', '', '2011-09-18 23:11:49', '2011-09-18 23:12:10'),
(10, 'Middle East', '', '2011-09-18 23:11:50', '2011-09-18 23:12:07'),
(11, 'East Asia', '', '2011-09-18 23:11:51', '2011-09-18 23:12:05'),
(12, 'Far East', '', '2011-09-18 23:11:54', '2011-09-18 23:12:02'),
(13, 'Central Asia', '', '2011-09-18 23:11:54', '2011-09-18 23:12:24'),
(14, 'South America', '', '2011-09-18 23:11:53', '2011-09-18 23:11:58'),
(15, 'Central America', '', '2011-09-18 23:11:55', '2011-09-18 23:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblReportTypes`
--

DROP TABLE IF EXISTS `tblReportTypes`;
CREATE TABLE IF NOT EXISTS `tblReportTypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `info` varchar(256) NOT NULL,
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblReportTypes`
--

INSERT INTO `tblReportTypes` (`id`, `name`, `info`, `added`, `modified`) VALUES
(1, 'Jobs Available', 'Available Jobs by Location & FB Comparison.', '2011-09-26 22:04:59', '2011-09-26 22:05:23'),
(2, 'Jobs Report', 'Weekly My Jobs report that showcases the jobs you have taken action on and or are potentially good for a match.', '2011-09-26 22:06:40', '2011-09-26 22:06:40'),
(3, 'Installed Report', 'Apps you have installed with Odd Job', '2011-09-26 22:07:04', '2011-09-26 22:07:04'),
(4, 'Nearby Report', 'Jobs nearby report', '2011-09-26 22:07:19', '2011-09-26 22:07:19');

-- --------------------------------------------------------

--
-- Table structure for table `tblSignupDevelopers`
--

DROP TABLE IF EXISTS `tblSignupDevelopers`;
CREATE TABLE IF NOT EXISTS `tblSignupDevelopers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comp_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` char(12) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblSignupDevelopers`
--

INSERT INTO `tblSignupDevelopers` (`id`, `name`, `comp_name`, `email`, `phone`, `pass`, `added`) VALUES
(1, 'sdsadsad', 'sdsadsad', 'asdsadsda', '', 'aaa', '2011-12-09 16:55:30'),
(2, 'sdsadsad', 'sdsadsad', 'asdsadsda', '', 'bbb', '2011-12-09 16:56:47'),
(3, 'fdsfsf', 'sfdsfsf', 'sdfdsfdsf', '', 'aaa', '2011-12-09 18:55:47'),
(4, 'ssasadas', 'sadsadads', 'ascasa', '444.444.4444', 'ddd', '2011-12-11 11:25:46');

-- --------------------------------------------------------

--
-- Table structure for table `tblSignupMerchants`
--

DROP TABLE IF EXISTS `tblSignupMerchants`;
CREATE TABLE IF NOT EXISTS `tblSignupMerchants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comp_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` char(12) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tblSignupMerchants`
--

INSERT INTO `tblSignupMerchants` (`id`, `name`, `comp_name`, `email`, `phone`, `pass`, `added`) VALUES
(1, 'asdassad', 'dasdasdd', 'adasasd', '', 'qqq', '2011-12-09 16:57:29'),
(2, 'sdasdds', 'saasdds', 'dsaddaasd', '111.111.1111', 'sss', '2011-12-11 11:25:22');

-- --------------------------------------------------------

--
-- Table structure for table `tblSignupUsers`
--

DROP TABLE IF EXISTS `tblSignupUsers`;
CREATE TABLE IF NOT EXISTS `tblSignupUsers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(255) NOT NULL,
  `invites` text NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblSignupUsers`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblSuppliersObjects`
--

DROP TABLE IF EXISTS `tblSuppliersObjects`;
CREATE TABLE IF NOT EXISTS `tblSuppliersObjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblSuppliersObjects`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblUsers`
--

DROP TABLE IF EXISTS `tblUsers`;
CREATE TABLE IF NOT EXISTS `tblUsers` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(128) NOT NULL,
  `fName` varchar(128) NOT NULL,
  `lName` varchar(128) NOT NULL,
  `age` int(128) NOT NULL DEFAULT '0',
  `sex` char(1) NOT NULL,
  `hometown` varchar(128) NOT NULL,
  `edu_id` varchar(128) NOT NULL DEFAULT '0',
  `locality_id` int(128) NOT NULL DEFAULT '0',
  `profession` varchar(256) NOT NULL,
  `email` varchar(255) NOT NULL,
  `device_id` varchar(72) NOT NULL,
  `friends` int(11) NOT NULL DEFAULT '0',
  `longitude` float NOT NULL DEFAULT '0',
  `latitude` float NOT NULL DEFAULT '0',
  `points` int(11) NOT NULL DEFAULT '0',
  `earned` float NOT NULL DEFAULT '0',
  `added` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tblUsers`
--

INSERT INTO `tblUsers` (`id`, `fb_id`, `fName`, `lName`, `age`, `sex`, `hometown`, `edu_id`, `locality_id`, `profession`, `email`, `device_id`, `friends`, `longitude`, `latitude`, `points`, `earned`, `added`, `modified`) VALUES
(1, '660042243', 'Matthew', 'Holcombe', 30, 'M', 'Islamorada, FL', '2', 2, '', '', '44a83c99 1875a327 456f4c1a 33622bd6 d5a0cdb6 d9b76289 d60e8be1 31c95502', 120, -122.165, 37.4637, 0, 0, '2011-09-16 13:14:36', '2011-12-13 19:16:28'),
(2, '1390251585', 'Jason', 'Festa', 29, 'M', 'Boca Raton, FL', '2', 1, '', '', '44a83c99 1875a327 456f4c1a 33622bd6 d5a0cdb6 d9b76289 d60e8be1 31c95502', 300, -122.163, 37.4615, 0, 0, '2011-09-18 23:14:46', '2011-12-08 22:00:23'),
(3, '1554917948', 'Toofus', 'Magnus', 30, 'M', 'Naples, FL', '2', 3, '', '', '', 50, -122.165, 37.4638, 0, 0, '2011-09-22 15:41:34', '2011-10-31 08:46:25'),
(4, '100000901448617', 'Arthur', 'Pewty', 14, 'M', 'Liverpool', '1', 2, '', '', '', 25, -122.419, 37.7793, 0, 0, '2011-09-22 15:41:40', '2011-10-26 15:23:52'),
(5, '100000936690098', 'Diedre', 'Pewty', 18, 'F', 'Liverpool', '1', 6, '', '', '', 30, -97.75, 30.25, 0, 0, '2011-09-22 15:41:54', '2011-10-26 15:24:56'),
(6, '100001070614958', 'Ken', 'Shabby', 21, 'M', 'Mousehole', '1', 7, '', '', '', 5, -5.539, 50.083, 0, 0, '2011-09-22 15:51:34', '2011-10-26 15:22:03'),
(7, '371924639492', 'Ron', 'Obvious', 40, 'M', 'London', '2', 4, '', '', '', 2500, -74, 40.7167, 0, 0, '2011-09-22 16:05:31', '2011-10-26 15:22:51'),
(9, '1234648027', 'Jesse', 'Boley', 27, 'M', '', '2', 1, '', '', '', 100, -122.179, 37.4542, 0, 0, '2011-09-29 22:12:50', '2011-10-26 15:25:36');

-- --------------------------------------------------------

--
-- Table structure for table `tblUsersFavJobs`
--

DROP TABLE IF EXISTS `tblUsersFavJobs`;
CREATE TABLE IF NOT EXISTS `tblUsersFavJobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` varchar(255) NOT NULL,
  `job_id` int(11) NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `tblUsersFavJobs`
--

INSERT INTO `tblUsersFavJobs` (`id`, `fb_id`, `job_id`, `added`) VALUES
(28, '660042243', 100, '2011-12-13 18:11:46');

-- --------------------------------------------------------

--
-- Table structure for table `tblUsersJobs`
--

DROP TABLE IF EXISTS `tblUsersJobs`;
CREATE TABLE IF NOT EXISTS `tblUsersJobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(128) NOT NULL DEFAULT '0',
  `job_id` int(128) NOT NULL DEFAULT '0',
  `status_id` int(128) NOT NULL DEFAULT '0',
  `added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1394 ;

--
-- Dumping data for table `tblUsersJobs`
--

INSERT INTO `tblUsersJobs` (`id`, `user_id`, `job_id`, `status_id`, `added`) VALUES
(1, 0, 0, 0, '2011-09-19 16:06:31'),
(2, 1, 1, 4, '2011-09-19 16:07:27'),
(17, 1, 1, 5, '2011-09-20 15:27:40'),
(18, 0, 1, 5, '2011-09-21 18:52:32'),
(308, 0, 2, 0, '2011-10-23 02:15:00'),
(307, 0, 2, 0, '2011-10-23 02:14:39'),
(186, 0, 0, 0, '2011-10-17 14:27:16'),
(306, 0, 2, 0, '2011-10-23 02:13:51'),
(305, 0, 2, 0, '2011-10-23 02:13:29'),
(185, 0, 0, 0, '2011-10-17 14:27:16'),
(304, 0, 2, 0, '2011-10-23 02:13:28'),
(303, 0, 2, 0, '2011-10-23 02:13:26'),
(302, 0, 2, 0, '2011-10-23 02:13:25'),
(301, 0, 2, 0, '2011-10-23 02:13:23'),
(300, 0, 2, 0, '2011-10-23 02:13:23'),
(184, 0, 0, 0, '2011-10-17 14:27:15'),
(299, 0, 2, 0, '2011-10-23 02:11:25'),
(298, 0, 2, 0, '2011-10-23 02:07:18'),
(183, 0, 0, 0, '2011-10-17 14:27:14'),
(182, 0, 0, 0, '2011-10-17 14:27:14'),
(297, 0, 2, 0, '2011-10-23 02:06:53'),
(296, 0, 2, 0, '2011-10-23 02:06:52'),
(295, 0, 2, 0, '2011-10-23 02:06:02'),
(294, 0, 2, 0, '2011-10-23 02:06:02'),
(293, 0, 2, 0, '2011-10-23 02:02:50'),
(292, 0, 2, 0, '2011-10-23 02:02:49'),
(291, 0, 2, 0, '2011-10-23 02:02:32'),
(290, 0, 2, 0, '2011-10-23 02:02:32'),
(289, 0, 2, 0, '2011-10-23 01:58:11'),
(181, 660042243, 2, 6, '2011-10-17 14:27:13'),
(180, 660042243, 3, 7, '2011-10-16 23:18:20'),
(288, 0, 2, 0, '2011-10-23 01:58:07'),
(287, 0, 2, 0, '2011-10-23 01:57:16'),
(286, 0, 2, 0, '2011-10-23 01:56:44'),
(285, 0, 2, 0, '2011-10-23 01:29:30'),
(284, 0, 100, 0, '2011-10-23 01:28:53'),
(283, 660042243, 1, 6, '2011-10-23 01:26:41'),
(282, 660042243, 2, 6, '2011-10-23 01:18:55'),
(281, 660042243, 2, 6, '2011-10-23 01:17:06'),
(280, 660042243, 3, 6, '2011-10-23 01:16:28'),
(279, 660042243, 2, 6, '2011-10-23 01:15:52'),
(278, 660042243, 2, 7, '2011-10-22 20:35:23'),
(277, 0, 100, 0, '2011-10-22 20:29:30'),
(276, 0, 100, 0, '2011-10-22 19:23:30'),
(275, 0, 2, 0, '2011-10-22 19:23:18'),
(274, 0, 100, 0, '2011-10-22 19:21:24'),
(273, 0, 100, 0, '2011-10-22 19:20:45'),
(272, 0, 1, 0, '2011-10-22 19:20:25'),
(271, 660042243, 2, 7, '2011-10-21 17:12:51'),
(270, 660042243, 2, 6, '2011-10-21 16:58:18'),
(269, 660042243, 2, 6, '2011-10-21 16:55:47'),
(268, 660042243, 2, 6, '2011-10-21 16:55:22'),
(267, 660042243, 2, 7, '2011-10-21 16:49:43'),
(266, 660042243, 2, 6, '2011-10-21 16:36:40'),
(265, 660042243, 2, 6, '2011-10-21 16:35:49'),
(264, 660042243, 2, 6, '2011-10-21 16:34:29'),
(263, 660042243, 2, 6, '2011-10-21 16:32:11'),
(262, 660042243, 2, 6, '2011-10-21 16:30:23'),
(261, 660042243, 2, 6, '2011-10-21 16:29:51'),
(260, 660042243, 2, 7, '2011-10-21 15:19:35'),
(259, 660042243, 2, 7, '2011-10-21 14:54:09'),
(258, 660042243, 2, 7, '2011-10-21 14:36:11'),
(257, 660042243, 2, 7, '2011-10-21 14:35:19'),
(256, 660042243, 2, 7, '2011-10-21 14:34:30'),
(255, 660042243, 2, 7, '2011-10-21 14:33:12'),
(254, 660042243, 2, 7, '2011-10-21 14:32:21'),
(253, 660042243, 3, 7, '2011-10-21 14:14:45'),
(252, 660042243, 4, 7, '2011-10-21 13:03:24'),
(251, 660042243, 3, 7, '2011-10-21 13:02:43'),
(250, 660042243, 2, 7, '2011-10-21 13:02:09'),
(249, 660042243, 3, 6, '2011-10-21 10:07:24'),
(248, 660042243, 2, 6, '2011-10-19 19:39:42'),
(247, 660042243, 2, 6, '2011-10-19 17:31:33'),
(246, 660042243, 3, 7, '2011-10-18 22:16:23'),
(245, 660042243, 1, 7, '2011-10-18 20:58:28'),
(244, 0, 3, 7, '2011-10-17 23:37:00'),
(243, 0, 3, 7, '2011-10-17 23:36:30'),
(242, 0, 3, 7, '2011-10-17 23:34:43'),
(241, 0, 3, 7, '2011-10-17 23:32:57'),
(240, 0, 2, 7, '2011-10-17 23:04:38'),
(239, 0, 2, 7, '2011-10-17 23:03:42'),
(238, 0, 2, 7, '2011-10-17 23:01:30'),
(237, 0, 3, 7, '2011-10-17 22:51:39'),
(236, 0, 4, 7, '2011-10-17 22:50:01'),
(235, 0, 4, 7, '2011-10-17 22:49:04'),
(234, 0, 2, 7, '2011-10-17 22:46:47'),
(233, 660042243, 4, 6, '2011-10-17 17:40:35'),
(232, 660042243, 3, 6, '2011-10-17 16:24:00'),
(231, 660042243, 4, 6, '2011-10-17 16:21:57'),
(230, 660042243, 3, 6, '2011-10-17 16:21:40'),
(229, 660042243, 3, 6, '2011-10-17 16:19:06'),
(228, 0, 0, 0, '2011-10-17 14:29:20'),
(227, 0, 0, 0, '2011-10-17 14:29:20'),
(226, 0, 0, 0, '2011-10-17 14:29:19'),
(225, 0, 0, 0, '2011-10-17 14:29:19'),
(224, 0, 0, 0, '2011-10-17 14:29:19'),
(223, 0, 0, 0, '2011-10-17 14:29:18'),
(222, 0, 0, 0, '2011-10-17 14:29:18'),
(221, 0, 0, 0, '2011-10-17 14:29:17'),
(220, 0, 0, 0, '2011-10-17 14:29:17'),
(219, 0, 0, 0, '2011-10-17 14:29:16'),
(218, 0, 0, 0, '2011-10-17 14:29:16'),
(217, 0, 0, 0, '2011-10-17 14:29:16'),
(216, 660042243, 3, 6, '2011-10-17 14:28:59'),
(215, 0, 0, 0, '2011-10-17 14:27:35'),
(214, 0, 0, 0, '2011-10-17 14:27:34'),
(213, 0, 0, 0, '2011-10-17 14:27:34'),
(179, 660042243, 3, 6, '2011-10-16 23:07:35'),
(212, 0, 0, 0, '2011-10-17 14:27:33'),
(211, 0, 0, 0, '2011-10-17 14:27:33'),
(210, 0, 0, 0, '2011-10-17 14:27:32'),
(209, 0, 0, 0, '2011-10-17 14:27:30'),
(208, 0, 0, 0, '2011-10-17 14:27:30'),
(207, 0, 0, 0, '2011-10-17 14:27:29'),
(206, 0, 0, 0, '2011-10-17 14:27:29'),
(205, 0, 0, 0, '2011-10-17 14:27:28'),
(204, 0, 0, 0, '2011-10-17 14:27:27'),
(203, 0, 0, 0, '2011-10-17 14:27:27'),
(202, 0, 0, 0, '2011-10-17 14:27:26'),
(201, 0, 0, 0, '2011-10-17 14:27:25'),
(200, 0, 0, 0, '2011-10-17 14:27:25'),
(199, 0, 0, 0, '2011-10-17 14:27:24'),
(198, 0, 0, 0, '2011-10-17 14:27:23'),
(197, 0, 0, 0, '2011-10-17 14:27:23'),
(196, 0, 0, 0, '2011-10-17 14:27:22'),
(195, 0, 0, 0, '2011-10-17 14:27:21'),
(194, 0, 0, 0, '2011-10-17 14:27:20'),
(193, 0, 0, 0, '2011-10-17 14:27:20'),
(192, 0, 0, 0, '2011-10-17 14:27:19'),
(191, 0, 0, 0, '2011-10-17 14:27:19'),
(190, 0, 0, 0, '2011-10-17 14:27:18'),
(189, 0, 0, 0, '2011-10-17 14:27:18'),
(188, 0, 0, 0, '2011-10-17 14:27:17'),
(187, 0, 0, 0, '2011-10-17 14:27:17'),
(178, 660042243, 3, 6, '2011-10-16 19:20:22'),
(177, 660042243, 3, 6, '2011-10-16 19:19:52'),
(176, 660042243, 2, 6, '2011-10-16 19:17:57'),
(175, 660042243, 3, 6, '2011-10-16 15:00:42'),
(174, 660042243, 3, 6, '2011-10-15 23:10:42'),
(173, 660042243, 2, 6, '2011-10-15 23:05:31'),
(172, 660042243, 2, 6, '2011-10-15 22:57:29'),
(171, 660042243, 2, 6, '2011-10-15 22:49:49'),
(170, 660042243, 3, 6, '2011-10-15 20:07:39'),
(169, 660042243, 4, 6, '2011-10-15 19:06:29'),
(309, 0, 2, 0, '2011-10-23 02:15:35'),
(310, 0, 2, 0, '2011-10-23 02:16:15'),
(311, 0, 2, 0, '2011-10-23 02:16:16'),
(312, 0, 2, 0, '2011-10-23 02:16:25'),
(313, 0, 2, 0, '2011-10-23 02:18:37'),
(314, 660042243, 2, 6, '2011-10-23 02:20:46'),
(315, 660042243, 1, 6, '2011-10-23 02:20:56'),
(316, 0, 2, 0, '2011-10-23 02:23:59'),
(317, 0, 2, 0, '2011-10-23 02:25:32'),
(318, 0, 2, 0, '2011-10-23 02:32:07'),
(319, 0, 2, 0, '2011-10-23 02:32:35'),
(320, 0, 2, 0, '2011-10-23 02:32:36'),
(321, 0, 2, 0, '2011-10-23 02:33:33'),
(322, 0, 2, 0, '2011-10-23 02:33:33'),
(323, 0, 2, 0, '2011-10-23 02:34:00'),
(324, 0, 2, 0, '2011-10-23 02:36:40'),
(325, 0, 2, 0, '2011-10-23 02:36:40'),
(326, 0, 2, 0, '2011-10-23 02:38:03'),
(327, 0, 2, 0, '2011-10-23 02:38:03'),
(328, 0, 2, 0, '2011-10-23 02:43:31'),
(329, 0, 2, 0, '2011-10-23 02:44:53'),
(330, 0, 2, 0, '2011-10-23 02:48:35'),
(331, 0, 2, 0, '2011-10-23 02:48:35'),
(332, 0, 2, 0, '2011-10-23 02:51:40'),
(333, 0, 2, 0, '2011-10-23 02:51:41'),
(334, 0, 2, 0, '2011-10-23 02:52:49'),
(335, 0, 2, 0, '2011-10-23 02:52:49'),
(336, 0, 2, 0, '2011-10-23 02:53:40'),
(337, 0, 2, 0, '2011-10-23 02:53:40'),
(338, 0, 2, 0, '2011-10-23 02:54:14'),
(339, 0, 2, 0, '2011-10-23 02:54:14'),
(340, 0, 2, 0, '2011-10-23 02:54:26'),
(341, 0, 2, 0, '2011-10-23 02:54:27'),
(342, 0, 2, 0, '2011-10-23 02:55:16'),
(343, 0, 2, 0, '2011-10-23 02:55:16'),
(344, 0, 2, 0, '2011-10-23 02:56:05'),
(345, 0, 2, 0, '2011-10-23 02:56:05'),
(346, 0, 2, 0, '2011-10-23 02:56:33'),
(347, 0, 2, 0, '2011-10-23 02:56:33'),
(348, 0, 2, 0, '2011-10-23 02:58:09'),
(349, 0, 2, 0, '2011-10-23 02:58:10'),
(350, 0, 2, 0, '2011-10-23 02:59:49'),
(351, 0, 2, 0, '2011-10-23 02:59:50'),
(352, 0, 2, 0, '2011-10-23 03:00:37'),
(353, 0, 2, 0, '2011-10-23 03:00:37'),
(354, 0, 2, 0, '2011-10-23 03:01:43'),
(355, 0, 2, 0, '2011-10-23 03:01:43'),
(356, 0, 2, 0, '2011-10-23 03:02:06'),
(357, 0, 2, 0, '2011-10-23 03:02:07'),
(358, 0, 2, 0, '2011-10-23 03:02:25'),
(359, 0, 2, 0, '2011-10-23 03:02:25'),
(360, 0, 2, 0, '2011-10-23 03:02:35'),
(361, 0, 2, 0, '2011-10-23 03:02:35'),
(362, 0, 2, 0, '2011-10-23 03:02:54'),
(363, 0, 2, 0, '2011-10-23 03:02:54'),
(364, 0, 2, 0, '2011-10-23 03:03:48'),
(365, 0, 2, 0, '2011-10-23 03:03:48'),
(366, 0, 2, 0, '2011-10-23 03:04:23'),
(367, 0, 2, 0, '2011-10-23 03:04:23'),
(368, 0, 2, 0, '2011-10-23 03:05:58'),
(369, 0, 2, 0, '2011-10-23 03:05:59'),
(370, 0, 2, 0, '2011-10-23 03:15:56'),
(371, 0, 2, 0, '2011-10-23 03:15:56'),
(372, 0, 2, 0, '2011-10-23 03:17:18'),
(373, 0, 2, 0, '2011-10-23 03:17:18'),
(374, 0, 2, 0, '2011-10-23 03:17:35'),
(375, 0, 2, 0, '2011-10-23 03:17:35'),
(376, 0, 2, 0, '2011-10-23 03:18:04'),
(377, 0, 2, 0, '2011-10-23 03:18:04'),
(378, 0, 2, 0, '2011-10-23 03:18:31'),
(379, 0, 2, 0, '2011-10-23 03:18:31'),
(380, 0, 2, 0, '2011-10-23 03:19:06'),
(381, 0, 2, 0, '2011-10-23 03:19:06'),
(382, 0, 2, 0, '2011-10-23 03:19:52'),
(383, 0, 2, 0, '2011-10-23 03:19:52'),
(384, 0, 2, 0, '2011-10-23 03:20:32'),
(385, 0, 2, 0, '2011-10-23 03:20:33'),
(386, 0, 2, 0, '2011-10-23 03:21:09'),
(387, 0, 2, 0, '2011-10-23 03:21:09'),
(388, 0, 2, 0, '2011-10-23 03:21:19'),
(389, 0, 2, 0, '2011-10-23 03:21:20'),
(390, 0, 2, 0, '2011-10-23 03:21:34'),
(391, 0, 2, 0, '2011-10-23 03:21:34'),
(392, 0, 2, 0, '2011-10-23 03:24:56'),
(393, 0, 2, 0, '2011-10-23 03:24:56'),
(394, 0, 2, 0, '2011-10-23 03:26:17'),
(395, 0, 2, 0, '2011-10-23 03:26:18'),
(396, 0, 2, 0, '2011-10-23 03:32:33'),
(397, 0, 2, 0, '2011-10-23 03:32:34'),
(398, 660042243, 4, 6, '2011-10-23 03:59:05'),
(399, 660042243, 3, 6, '2011-10-23 05:20:08'),
(400, 660042243, 2, 6, '2011-10-23 09:20:02'),
(401, 660042243, 2, 6, '2011-10-23 12:33:03'),
(402, 660042243, 2, 6, '2011-10-23 12:35:36'),
(403, 660042243, 2, 6, '2011-10-23 12:44:44'),
(404, 660042243, 3, 6, '2011-10-23 12:44:48'),
(405, 660042243, 4, 6, '2011-10-23 12:44:50'),
(406, 660042243, 1, 6, '2011-10-23 12:44:55'),
(407, 660042243, 2, 6, '2011-10-23 12:53:08'),
(408, 660042243, 3, 6, '2011-10-23 12:53:10'),
(409, 660042243, 4, 6, '2011-10-23 12:53:12'),
(410, 660042243, 1, 6, '2011-10-23 12:54:21'),
(411, 660042243, 4, 6, '2011-10-23 13:08:15'),
(412, 660042243, 2, 6, '2011-10-23 13:08:51'),
(413, 660042243, 4, 6, '2011-10-23 13:13:08'),
(414, 660042243, 2, 6, '2011-10-23 13:14:45'),
(415, 660042243, 6, 6, '2011-10-23 15:38:27'),
(416, 0, 4, 0, '2011-10-23 16:21:51'),
(417, 0, 4, 0, '2011-10-23 16:21:52'),
(418, 660042243, 13, 6, '2011-10-23 17:28:13'),
(419, 660042243, 7, 6, '2011-10-23 17:30:15'),
(420, 660042243, 7, 6, '2011-10-23 17:50:43'),
(421, 660042243, 7, 6, '2011-10-23 17:51:17'),
(422, 660042243, 7, 6, '2011-10-23 17:53:18'),
(423, 660042243, 7, 6, '2011-10-23 17:53:51'),
(424, 660042243, 7, 6, '2011-10-23 17:54:30'),
(425, 660042243, 7, 6, '2011-10-23 17:54:49'),
(426, 660042243, 7, 6, '2011-10-23 17:55:37'),
(427, 660042243, 7, 6, '2011-10-23 17:56:48'),
(428, 660042243, 7, 6, '2011-10-23 17:57:16'),
(429, 660042243, 7, 6, '2011-10-23 17:57:39'),
(430, 660042243, 7, 6, '2011-10-23 17:59:03'),
(431, 660042243, 7, 6, '2011-10-23 17:59:24'),
(432, 660042243, 7, 6, '2011-10-23 17:59:56'),
(433, 660042243, 7, 6, '2011-10-23 18:01:14'),
(434, 660042243, 7, 6, '2011-10-23 18:01:48'),
(435, 660042243, 7, 6, '2011-10-23 18:02:51'),
(436, 660042243, 7, 6, '2011-10-23 18:03:24'),
(437, 660042243, 7, 6, '2011-10-23 18:03:53'),
(438, 660042243, 7, 6, '2011-10-23 18:04:30'),
(439, 660042243, 7, 6, '2011-10-23 18:04:49'),
(440, 660042243, 7, 6, '2011-10-23 18:06:07'),
(441, 660042243, 7, 6, '2011-10-23 18:08:57'),
(442, 660042243, 7, 6, '2011-10-23 18:09:26'),
(443, 660042243, 7, 6, '2011-10-23 18:09:38'),
(444, 660042243, 7, 6, '2011-10-23 18:10:10'),
(445, 660042243, 7, 6, '2011-10-23 18:10:36'),
(446, 660042243, 7, 6, '2011-10-23 18:11:02'),
(447, 660042243, 7, 6, '2011-10-23 18:17:55'),
(448, 660042243, 7, 6, '2011-10-23 18:18:32'),
(449, 660042243, 7, 6, '2011-10-23 18:19:15'),
(450, 660042243, 7, 6, '2011-10-23 18:19:33'),
(451, 660042243, 7, 6, '2011-10-23 18:25:13'),
(452, 660042243, 7, 6, '2011-10-23 18:26:28'),
(453, 660042243, 7, 6, '2011-10-23 18:26:58'),
(454, 660042243, 7, 6, '2011-10-23 18:27:27'),
(455, 660042243, 7, 6, '2011-10-23 18:28:47'),
(456, 660042243, 7, 6, '2011-10-23 18:29:01'),
(457, 660042243, 7, 6, '2011-10-23 18:29:48'),
(458, 660042243, 7, 6, '2011-10-23 18:30:12'),
(459, 660042243, 7, 6, '2011-10-23 18:32:19'),
(460, 660042243, 8, 6, '2011-10-23 18:32:50'),
(461, 660042243, 8, 6, '2011-10-23 18:33:22'),
(462, 660042243, 8, 6, '2011-10-23 18:33:58'),
(463, 660042243, 8, 6, '2011-10-23 18:34:24'),
(464, 660042243, 8, 6, '2011-10-23 18:34:56'),
(465, 660042243, 8, 6, '2011-10-23 18:35:47'),
(466, 660042243, 8, 6, '2011-10-23 18:36:08'),
(467, 660042243, 8, 6, '2011-10-23 18:37:12'),
(468, 660042243, 12, 6, '2011-10-23 18:45:26'),
(469, 660042243, 13, 6, '2011-10-23 18:47:11'),
(470, 660042243, 6, 6, '2011-10-23 18:47:31'),
(471, 660042243, 10, 6, '2011-10-23 18:47:38'),
(472, 660042243, 7, 6, '2011-10-23 18:47:47'),
(473, 660042243, 5, 6, '2011-10-23 18:48:06'),
(474, 660042243, 14, 6, '2011-10-23 18:48:30'),
(475, 660042243, 7, 6, '2011-10-23 18:50:37'),
(476, 0, 4, 0, '2011-10-24 09:27:12'),
(477, 0, 4, 0, '2011-10-24 09:27:13'),
(478, 660042243, 8, 6, '2011-10-24 16:48:33'),
(479, 660042243, 13, 6, '2011-10-24 16:48:54'),
(480, 660042243, 2, 6, '2011-10-24 16:49:11'),
(481, 660042243, 10, 6, '2011-10-24 16:49:24'),
(482, 660042243, 5, 6, '2011-10-24 16:52:57'),
(483, 660042243, 5, 6, '2011-10-24 16:53:44'),
(484, 660042243, 4, 6, '2011-10-24 16:58:09'),
(485, 660042243, 8, 6, '2011-10-24 18:57:17'),
(486, 1390251585, 6, 6, '2011-10-24 19:01:19'),
(487, 1390251585, 9, 6, '2011-10-24 19:01:39'),
(488, 1390251585, 5, 6, '2011-10-24 19:02:55'),
(489, 1390251585, 10, 6, '2011-10-24 19:03:00'),
(490, 1390251585, 11, 6, '2011-10-24 19:07:32'),
(491, 1390251585, 12, 6, '2011-10-24 19:08:33'),
(492, 1390251585, 1, 6, '2011-10-24 19:09:59'),
(493, 1390251585, 7, 6, '2011-10-24 19:10:13'),
(494, 1390251585, 4, 6, '2011-10-24 19:12:01'),
(495, 1390251585, 2, 6, '2011-10-24 19:12:13'),
(496, 1390251585, 13, 6, '2011-10-24 19:13:32'),
(497, 660042243, 7, 6, '2011-10-24 20:02:43'),
(498, 660042243, 8, 6, '2011-10-24 20:02:50'),
(499, 660042243, 7, 6, '2011-10-24 20:04:12'),
(500, 660042243, 7, 6, '2011-10-24 20:04:30'),
(501, 660042243, 7, 6, '2011-10-24 20:04:42'),
(502, 660042243, 7, 6, '2011-10-24 20:04:59'),
(503, 660042243, 7, 6, '2011-10-24 20:05:28'),
(504, 660042243, 8, 6, '2011-10-24 20:05:40'),
(505, 660042243, 2, 6, '2011-10-24 20:06:40'),
(506, 660042243, 13, 6, '2011-10-24 20:06:49'),
(507, 660042243, 8, 6, '2011-10-24 20:07:15'),
(508, 660042243, 7, 6, '2011-10-24 20:07:28'),
(509, 660042243, 4, 6, '2011-10-24 20:07:40'),
(510, 660042243, 5, 6, '2011-10-24 20:07:45'),
(511, 660042243, 6, 6, '2011-10-24 20:07:54'),
(512, 660042243, 9, 6, '2011-10-24 20:08:05'),
(513, 660042243, 10, 6, '2011-10-24 20:08:18'),
(514, 660042243, 8, 6, '2011-10-24 20:08:43'),
(515, 660042243, 5, 6, '2011-10-24 20:08:50'),
(516, 660042243, 11, 6, '2011-10-24 20:09:03'),
(517, 660042243, 7, 6, '2011-10-24 21:07:02'),
(518, 660042243, 7, 6, '2011-10-24 21:08:30'),
(519, 660042243, 7, 6, '2011-10-24 21:09:03'),
(520, 660042243, 8, 6, '2011-10-24 21:11:39'),
(521, 660042243, 8, 6, '2011-10-24 21:13:05'),
(522, 660042243, 8, 6, '2011-10-24 21:13:12'),
(523, 660042243, 8, 6, '2011-10-24 21:14:05'),
(524, 660042243, 13, 6, '2011-10-24 21:14:50'),
(525, 660042243, 7, 6, '2011-10-24 21:31:21'),
(526, 660042243, 8, 6, '2011-10-24 21:31:27'),
(527, 660042243, 7, 6, '2011-10-24 21:39:21'),
(528, 660042243, 7, 6, '2011-10-24 21:42:44'),
(529, 660042243, 7, 6, '2011-10-24 21:43:52'),
(530, 660042243, 7, 6, '2011-10-24 21:45:05'),
(531, 660042243, 5, 6, '2011-10-24 21:45:50'),
(532, 1390251585, 7, 6, '2011-10-24 21:49:17'),
(533, 1390251585, 8, 6, '2011-10-24 21:50:50'),
(534, 1390251585, 8, 6, '2011-10-24 21:53:39'),
(535, 1390251585, 2, 6, '2011-10-24 21:55:10'),
(536, 1234648027, 7, 6, '2011-10-24 22:13:49'),
(537, 660042243, 7, 6, '2011-10-24 23:13:27'),
(538, 660042243, 8, 6, '2011-10-24 23:14:54'),
(539, 660042243, 7, 6, '2011-10-24 23:28:55'),
(540, 660042243, 7, 6, '2011-10-24 23:30:25'),
(541, 660042243, 2, 6, '2011-10-24 23:30:44'),
(542, 660042243, 8, 6, '2011-10-24 23:31:56'),
(543, 660042243, 13, 6, '2011-10-24 23:33:00'),
(544, 660042243, 7, 6, '2011-10-24 23:33:33'),
(545, 660042243, 7, 6, '2011-10-24 23:34:16'),
(546, 660042243, 7, 6, '2011-10-24 23:35:16'),
(547, 660042243, 8, 6, '2011-10-24 23:36:00'),
(548, 660042243, 8, 6, '2011-10-24 23:43:02'),
(549, 660042243, 8, 6, '2011-10-24 23:47:56'),
(550, 660042243, 8, 6, '2011-10-24 23:48:53'),
(551, 660042243, 8, 6, '2011-10-24 23:50:26'),
(552, 660042243, 8, 6, '2011-10-24 23:50:49'),
(553, 660042243, 8, 6, '2011-10-24 23:51:43'),
(554, 660042243, 8, 6, '2011-10-24 23:53:14'),
(555, 660042243, 8, 6, '2011-10-24 23:53:58'),
(556, 660042243, 8, 6, '2011-10-24 23:54:13'),
(557, 660042243, 8, 6, '2011-10-24 23:54:52'),
(558, 660042243, 8, 6, '2011-10-24 23:55:16'),
(559, 660042243, 8, 6, '2011-10-24 23:56:11'),
(560, 660042243, 8, 6, '2011-10-24 23:57:33'),
(561, 660042243, 8, 6, '2011-10-24 23:58:07'),
(562, 660042243, 8, 6, '2011-10-24 23:59:21'),
(563, 660042243, 8, 6, '2011-10-25 00:00:17'),
(564, 660042243, 8, 6, '2011-10-25 00:01:12'),
(565, 660042243, 8, 6, '2011-10-25 00:01:57'),
(566, 660042243, 8, 6, '2011-10-25 00:05:41'),
(567, 660042243, 8, 6, '2011-10-25 00:06:40'),
(568, 660042243, 8, 6, '2011-10-25 00:07:28'),
(569, 660042243, 8, 6, '2011-10-25 00:08:07'),
(570, 660042243, 8, 6, '2011-10-25 00:08:41'),
(571, 660042243, 8, 6, '2011-10-25 00:09:18'),
(572, 660042243, 8, 6, '2011-10-25 00:09:45'),
(573, 660042243, 8, 6, '2011-10-25 00:10:41'),
(574, 660042243, 8, 6, '2011-10-25 00:11:20'),
(575, 660042243, 8, 6, '2011-10-25 00:12:51'),
(576, 660042243, 8, 6, '2011-10-25 00:13:58'),
(577, 660042243, 8, 6, '2011-10-25 00:14:37'),
(578, 660042243, 8, 6, '2011-10-25 00:15:11'),
(579, 660042243, 8, 6, '2011-10-25 00:16:14'),
(580, 660042243, 8, 6, '2011-10-25 00:17:17'),
(581, 660042243, 2, 6, '2011-10-25 00:51:32'),
(582, 660042243, 8, 6, '2011-10-25 01:03:25'),
(583, 660042243, 8, 6, '2011-10-25 01:04:28'),
(584, 1390251585, 7, 6, '2011-10-25 01:05:55'),
(585, 1390251585, 9, 6, '2011-10-25 01:06:17'),
(586, 1390251585, 10, 6, '2011-10-25 01:06:21'),
(587, 1390251585, 6, 6, '2011-10-25 01:06:29'),
(588, 1390251585, 8, 6, '2011-10-25 01:06:50'),
(589, 1390251585, 7, 6, '2011-10-25 01:45:01'),
(590, 1390251585, 5, 6, '2011-10-25 01:46:05'),
(591, 1390251585, 8, 6, '2011-10-25 01:46:40'),
(592, 1390251585, 2, 6, '2011-10-25 01:58:09'),
(593, 1390251585, 11, 6, '2011-10-25 02:00:05'),
(594, 1390251585, 12, 6, '2011-10-25 02:06:21'),
(595, 1390251585, 4, 6, '2011-10-25 02:12:31'),
(596, 1390251585, 6, 6, '2011-10-25 03:19:43'),
(597, 1390251585, 11, 6, '2011-10-25 03:20:16'),
(598, 1390251585, 10, 6, '2011-10-25 03:20:29'),
(599, 1390251585, 9, 6, '2011-10-25 03:20:45'),
(600, 1390251585, 14, 6, '2011-10-25 03:21:21'),
(601, 1390251585, 2, 6, '2011-10-25 09:09:46'),
(602, 1390251585, 5, 6, '2011-10-25 09:10:11'),
(603, 1390251585, 13, 6, '2011-10-25 09:11:42'),
(604, 0, 4, 0, '2011-10-25 09:13:24'),
(605, 0, 4, 0, '2011-10-25 09:13:27'),
(606, 1390251585, 7, 6, '2011-10-25 09:15:10'),
(607, 1390251585, 8, 6, '2011-10-25 09:18:21'),
(608, 1390251585, 12, 6, '2011-10-25 12:22:39'),
(609, 1390251585, 5, 6, '2011-10-25 12:27:53'),
(610, 660042243, 7, 6, '2011-10-25 13:35:36'),
(611, 660042243, 8, 6, '2011-10-25 13:35:54'),
(612, 660042243, 2, 6, '2011-10-25 13:36:04'),
(613, 660042243, 6, 6, '2011-10-25 13:40:02'),
(614, 660042243, 4, 6, '2011-10-25 13:41:11'),
(615, 660042243, 4, 6, '2011-10-25 13:42:25'),
(616, 660042243, 7, 6, '2011-10-25 13:43:00'),
(617, 660042243, 7, 6, '2011-10-25 13:43:38'),
(618, 660042243, 7, 6, '2011-10-25 13:43:59'),
(619, 660042243, 7, 6, '2011-10-25 13:46:47'),
(620, 660042243, 7, 6, '2011-10-25 13:49:15'),
(621, 660042243, 7, 6, '2011-10-25 13:50:03'),
(622, 660042243, 7, 6, '2011-10-25 14:02:34'),
(623, 660042243, 7, 6, '2011-10-25 14:03:46'),
(624, 660042243, 7, 6, '2011-10-25 14:05:32'),
(625, 660042243, 8, 6, '2011-10-25 14:07:52'),
(626, 660042243, 8, 6, '2011-10-25 14:08:28'),
(627, 660042243, 7, 6, '2011-10-25 14:08:37'),
(628, 660042243, 7, 6, '2011-10-25 15:03:39'),
(629, 660042243, 5, 6, '2011-10-25 15:03:52'),
(630, 660042243, 7, 6, '2011-10-25 15:05:34'),
(631, 660042243, 8, 6, '2011-10-25 15:05:52'),
(632, 660042243, 13, 6, '2011-10-25 15:08:16'),
(633, 660042243, 4, 6, '2011-10-25 15:08:44'),
(634, 660042243, 5, 6, '2011-10-25 15:09:23'),
(635, 660042243, 6, 6, '2011-10-25 15:42:16'),
(636, 660042243, 7, 6, '2011-10-25 16:21:16'),
(637, 660042243, 7, 6, '2011-10-25 16:23:51'),
(638, 660042243, 8, 6, '2011-10-25 17:06:18'),
(639, 660042243, 6, 6, '2011-10-25 17:06:30'),
(640, 1390251585, 9, 6, '2011-10-25 19:14:29'),
(641, 1390251585, 9, 6, '2011-10-25 19:15:53'),
(642, 1390251585, 5, 6, '2011-10-25 19:17:32'),
(643, 1390251585, 6, 6, '2011-10-25 19:17:37'),
(644, 1390251585, 11, 6, '2011-10-25 19:17:45'),
(645, 1390251585, 10, 6, '2011-10-25 20:06:52'),
(646, 660042243, 5, 6, '2011-10-25 21:06:46'),
(647, 660042243, 14, 6, '2011-10-25 21:07:23'),
(648, 660042243, 12, 6, '2011-10-25 23:25:26'),
(649, 660042243, 9, 6, '2011-10-26 15:47:26'),
(650, 660042243, 4, 6, '2011-10-26 15:53:06'),
(651, 660042243, 6, 6, '2011-10-26 15:55:43'),
(652, 660042243, 9, 6, '2011-10-26 15:57:46'),
(653, 0, 2, 0, '2011-10-26 16:41:29'),
(654, 0, 2, 0, '2011-10-26 16:41:37'),
(655, 0, 2, 0, '2011-10-26 16:42:48'),
(656, 0, 2, 0, '2011-10-26 16:43:06'),
(657, 0, 2, 0, '2011-10-26 16:43:56'),
(658, 0, 2, 0, '2011-10-26 16:45:01'),
(659, 0, 2, 0, '2011-10-26 16:45:10'),
(660, 0, 2, 0, '2011-10-26 16:46:41'),
(661, 0, 2, 0, '2011-10-26 17:11:08'),
(662, 0, 2, 0, '2011-10-26 17:11:24'),
(663, 0, 2, 0, '2011-10-26 17:13:55'),
(664, 0, 2, 0, '2011-10-26 17:16:49'),
(665, 0, 2, 0, '2011-10-26 17:37:14'),
(666, 0, 5, 0, '2011-10-26 17:40:35'),
(667, 0, 5, 0, '2011-10-26 17:40:41'),
(668, 0, 5, 0, '2011-10-26 17:40:46'),
(669, 0, 2, 0, '2011-10-26 17:40:53'),
(670, 0, 5, 0, '2011-10-26 17:40:57'),
(671, 0, 5, 0, '2011-10-26 17:42:17'),
(672, 660042243, 11, 6, '2011-10-26 18:23:45'),
(673, 660042243, 9, 6, '2011-10-26 18:26:27'),
(674, 660042243, 5, 6, '2011-10-26 18:28:21'),
(675, 660042243, 12, 6, '2011-10-26 18:31:37'),
(676, 660042243, 9, 6, '2011-10-26 18:32:16'),
(677, 660042243, 6, 6, '2011-10-26 18:33:00'),
(678, 660042243, 7, 6, '2011-10-26 18:34:34'),
(679, 660042243, 9, 6, '2011-10-26 18:34:56'),
(680, 660042243, 5, 6, '2011-10-26 18:35:03'),
(681, 660042243, 11, 6, '2011-10-26 18:36:29'),
(682, 660042243, 5, 6, '2011-10-26 19:03:03'),
(683, 660042243, 2, 6, '2011-10-26 19:03:37'),
(684, 660042243, 8, 6, '2011-10-26 19:04:56'),
(685, 0, 5, 0, '2011-10-26 19:05:44'),
(686, 660042243, 14, 6, '2011-10-26 19:07:28'),
(687, 0, 5, 0, '2011-10-26 19:09:15'),
(688, 0, 5, 0, '2011-10-26 19:11:07'),
(689, 660042243, 11, 6, '2011-10-26 19:14:39'),
(690, 660042243, 13, 6, '2011-10-26 19:19:14'),
(691, 660042243, 10, 6, '2011-10-26 19:20:21'),
(692, 660042243, 9, 6, '2011-10-26 19:20:36'),
(693, 660042243, 14, 6, '2011-10-26 19:25:18'),
(694, 660042243, 2, 6, '2011-10-26 19:25:37'),
(695, 660042243, 7, 6, '2011-10-26 19:26:21'),
(696, 660042243, 4, 6, '2011-10-26 19:26:52'),
(697, 660042243, 6, 6, '2011-10-26 19:27:43'),
(698, 660042243, 6, 6, '2011-10-26 19:28:13'),
(699, 660042243, 5, 6, '2011-10-26 19:29:49'),
(700, 660042243, 11, 6, '2011-10-26 19:29:58'),
(701, 660042243, 2, 6, '2011-10-26 19:30:29'),
(702, 660042243, 4, 6, '2011-10-26 19:31:47'),
(703, 660042243, 5, 6, '2011-10-26 19:31:55'),
(704, 660042243, 12, 6, '2011-10-26 19:32:31'),
(705, 660042243, 8, 6, '2011-10-26 19:32:50'),
(706, 660042243, 4, 6, '2011-10-26 19:33:07'),
(707, 0, 5, 0, '2011-10-26 20:28:29'),
(708, 0, 5, 0, '2011-10-26 20:33:48'),
(709, 0, 5, 0, '2011-10-26 20:34:20'),
(710, 660042243, 14, 6, '2011-10-26 20:44:12'),
(711, 660042243, 10, 6, '2011-10-26 20:44:23'),
(712, 660042243, 13, 6, '2011-10-26 20:44:57'),
(713, 660042243, 4, 6, '2011-10-26 20:45:36'),
(714, 660042243, 5, 6, '2011-10-26 20:52:06'),
(715, 660042243, 6, 6, '2011-10-26 20:52:29'),
(716, 0, 1, 0, '2011-10-26 21:42:32'),
(717, 0, 2, 0, '2011-10-26 21:42:32'),
(718, 0, 3, 0, '2011-10-26 21:42:42'),
(719, 0, 4, 0, '2011-10-26 21:42:59'),
(720, 0, 5, 0, '2011-10-26 21:43:03'),
(721, 0, 6, 0, '2011-10-26 21:43:08'),
(722, 0, 7, 0, '2011-10-26 21:43:13'),
(723, 0, 8, 0, '2011-10-26 21:43:16'),
(724, 0, 9, 0, '2011-10-26 21:43:20'),
(725, 0, 100, 0, '2011-10-26 21:43:23'),
(726, 0, 10, 0, '2011-10-26 21:43:26'),
(727, 0, 11, 0, '2011-10-26 21:43:29'),
(728, 0, 12, 0, '2011-10-26 21:43:32'),
(729, 0, 13, 0, '2011-10-26 21:43:38'),
(730, 0, 14, 0, '2011-10-26 21:44:25'),
(731, 0, 15, 0, '2011-10-26 21:44:31'),
(732, 0, 2, 0, '2011-10-26 21:45:15'),
(733, 0, 3, 0, '2011-10-26 21:45:46'),
(734, 0, 2, 0, '2011-10-26 21:46:02'),
(735, 0, 3, 0, '2011-10-26 21:46:06'),
(736, 0, 6, 0, '2011-10-26 21:46:33'),
(737, 0, 6, 0, '2011-10-26 21:49:12'),
(738, 660042243, 6, 6, '2011-10-26 22:16:49'),
(739, 660042243, 6, 6, '2011-10-26 22:17:08'),
(740, 660042243, 6, 6, '2011-10-26 22:17:21'),
(741, 660042243, 6, 6, '2011-10-26 22:17:23'),
(742, 660042243, 6, 6, '2011-10-26 22:17:24'),
(743, 660042243, 6, 6, '2011-10-26 22:17:25'),
(744, 660042243, 6, 6, '2011-10-26 22:17:25'),
(745, 660042243, 6, 6, '2011-10-26 22:17:26'),
(746, 660042243, 6, 6, '2011-10-26 22:17:27'),
(747, 660042243, 6, 6, '2011-10-26 22:17:29'),
(748, 660042243, 6, 6, '2011-10-26 22:20:29'),
(749, 660042243, 6, 6, '2011-10-26 22:27:00'),
(750, 660042243, 6, 6, '2011-10-26 22:27:04'),
(751, 660042243, 6, 6, '2011-10-26 22:27:19'),
(752, 660042243, 6, 6, '2011-10-26 22:28:06'),
(753, 660042243, 0, 6, '2011-10-26 22:30:48'),
(754, 660042243, 0, 6, '2011-10-26 22:33:02'),
(755, 660042243, 0, 6, '2011-10-26 22:34:01'),
(756, 660042243, 6, 6, '2011-10-26 22:35:41'),
(757, 660042243, 6, 6, '2011-10-26 22:38:06'),
(758, 660042243, 6, 6, '2011-10-26 22:39:43'),
(759, 660042243, 6, 6, '2011-10-26 22:40:45'),
(760, 660042243, 6, 6, '2011-10-26 22:42:09'),
(761, 660042243, 6, 6, '2011-10-26 22:42:31'),
(762, 660042243, 2, 6, '2011-10-26 22:57:00'),
(763, 660042243, 5, 6, '2011-10-26 22:57:21'),
(764, 660042243, 5, 6, '2011-10-26 22:57:32'),
(765, 660042243, 2, 6, '2011-10-27 08:37:52'),
(766, 660042243, 6, 6, '2011-10-27 11:57:16'),
(767, 660042243, 10, 6, '2011-10-27 11:59:12'),
(768, 660042243, 2, 6, '2011-10-27 14:54:36'),
(769, 660042243, 12, 6, '2011-10-27 14:54:42'),
(770, 660042243, 4, 6, '2011-10-27 16:37:30'),
(771, 660042243, 10, 6, '2011-10-27 16:38:44'),
(772, 660042243, 9, 6, '2011-10-27 17:54:53'),
(773, 660042243, 2, 6, '2011-10-27 18:06:52'),
(774, 660042243, 2, 6, '2011-10-27 18:08:16'),
(775, 660042243, 11, 6, '2011-10-27 18:08:53'),
(776, 660042243, 11, 6, '2011-10-27 18:09:33'),
(777, 660042243, 5, 6, '2011-10-27 19:38:43'),
(778, 660042243, 9, 6, '2011-10-27 21:16:05'),
(779, 660042243, 7, 6, '2011-10-27 21:16:25'),
(780, 660042243, 12, 6, '2011-10-27 21:16:46'),
(781, 660042243, 10, 6, '2011-10-27 21:33:20'),
(782, 660042243, 6, 6, '2011-10-27 21:34:20'),
(783, 660042243, 8, 6, '2011-10-27 23:12:27'),
(784, 660042243, 2, 6, '2011-10-27 23:12:45'),
(785, 660042243, 11, 6, '2011-10-28 08:04:58'),
(786, 660042243, 4, 6, '2011-10-28 08:05:27'),
(787, 660042243, 10, 6, '2011-10-28 08:06:07'),
(788, 660042243, 14, 6, '2011-10-28 08:06:29'),
(789, 660042243, 14, 6, '2011-10-28 08:06:47'),
(790, 660042243, 6, 6, '2011-10-28 08:06:56'),
(791, 660042243, 6, 6, '2011-10-28 08:07:36'),
(792, 660042243, 12, 6, '2011-10-28 08:08:26'),
(793, 660042243, 7, 6, '2011-10-28 08:24:50'),
(794, 660042243, 13, 6, '2011-10-28 08:36:35'),
(795, 660042243, 2, 6, '2011-10-28 11:09:44'),
(796, 660042243, 9, 6, '2011-10-28 11:09:51'),
(797, 660042243, 6, 6, '2011-10-28 11:09:55'),
(798, 660042243, 11, 6, '2011-10-28 11:10:00'),
(799, 660042243, 13, 6, '2011-10-28 11:10:06'),
(800, 660042243, 2, 6, '2011-10-28 12:21:49'),
(801, 660042243, 11, 6, '2011-10-28 12:21:52'),
(802, 660042243, 12, 6, '2011-10-28 12:21:56'),
(803, 660042243, 10, 6, '2011-10-28 12:21:58'),
(804, 660042243, 6, 6, '2011-10-28 12:22:01'),
(805, 660042243, 9, 6, '2011-10-28 12:22:04'),
(806, 660042243, 11, 6, '2011-10-28 12:25:23'),
(807, 660042243, 10, 6, '2011-10-28 12:25:37'),
(808, 660042243, 4, 6, '2011-10-28 12:26:07'),
(809, 660042243, 11, 6, '2011-10-28 12:26:15'),
(810, 660042243, 11, 6, '2011-10-28 12:27:18'),
(811, 660042243, 6, 6, '2011-10-28 12:27:42'),
(812, 660042243, 11, 6, '2011-10-28 12:36:56'),
(813, 660042243, 2, 6, '2011-10-28 12:37:00'),
(814, 660042243, 6, 6, '2011-10-28 12:37:54'),
(815, 660042243, 6, 6, '2011-10-28 12:42:43'),
(816, 660042243, 11, 6, '2011-10-28 12:42:49'),
(817, 660042243, 9, 6, '2011-10-28 12:43:25'),
(818, 660042243, 11, 6, '2011-10-28 12:43:31'),
(819, 660042243, 10, 6, '2011-10-28 12:43:37'),
(820, 660042243, 6, 6, '2011-10-28 12:43:44'),
(821, 660042243, 2, 6, '2011-10-28 12:44:00'),
(822, 660042243, 12, 6, '2011-10-28 12:44:19'),
(823, 660042243, 4, 6, '2011-10-28 12:44:26'),
(824, 660042243, 6, 6, '2011-10-28 12:58:16'),
(825, 660042243, 10, 6, '2011-10-28 12:58:18'),
(826, 660042243, 11, 6, '2011-10-28 12:58:31'),
(827, 660042243, 2, 6, '2011-10-28 12:58:40'),
(828, 660042243, 8, 6, '2011-10-28 15:55:17'),
(829, 660042243, 7, 6, '2011-10-28 15:55:25'),
(830, 660042243, 13, 6, '2011-10-28 15:55:28'),
(831, 660042243, 14, 6, '2011-10-28 15:55:33'),
(832, 660042243, 5, 6, '2011-10-28 15:55:39'),
(833, 660042243, 9, 6, '2011-10-28 15:55:43'),
(834, 660042243, 11, 6, '2011-10-28 15:55:46'),
(835, 660042243, 2, 6, '2011-10-28 15:55:48'),
(836, 660042243, 10, 6, '2011-10-28 15:55:51'),
(837, 660042243, 12, 6, '2011-10-28 15:55:53'),
(838, 660042243, 4, 6, '2011-10-28 15:55:56'),
(839, 660042243, 6, 6, '2011-10-28 15:55:58'),
(840, 660042243, 12, 6, '2011-10-28 15:56:24'),
(841, 660042243, 12, 6, '2011-10-28 16:55:25'),
(842, 660042243, 4, 6, '2011-10-28 16:55:29'),
(843, 660042243, 10, 6, '2011-10-28 17:36:46'),
(844, 660042243, 14, 6, '2011-10-28 17:36:52'),
(845, 660042243, 14, 6, '2011-10-28 17:38:48'),
(846, 660042243, 6, 6, '2011-10-28 17:43:07'),
(847, 660042243, 2, 6, '2011-10-28 17:43:20'),
(848, 660042243, 8, 6, '2011-10-28 17:43:49'),
(849, 660042243, 9, 6, '2011-10-28 17:44:22'),
(850, 660042243, 14, 6, '2011-10-28 17:44:35'),
(851, 660042243, 11, 6, '2011-10-28 17:45:05'),
(852, 660042243, 10, 6, '2011-10-28 17:45:48'),
(853, 660042243, 12, 6, '2011-10-28 17:49:39'),
(854, 660042243, 8, 6, '2011-10-28 17:50:05'),
(855, 660042243, 4, 6, '2011-10-28 17:50:22'),
(856, 660042243, 11, 6, '2011-10-28 17:50:43'),
(857, 660042243, 10, 6, '2011-10-28 17:52:18'),
(858, 660042243, 9, 6, '2011-10-28 18:02:24'),
(859, 660042243, 2, 6, '2011-10-28 18:02:27'),
(860, 660042243, 6, 6, '2011-10-28 18:03:59'),
(861, 660042243, 12, 6, '2011-10-28 18:04:24'),
(862, 660042243, 11, 6, '2011-10-28 18:05:56'),
(863, 660042243, 8, 6, '2011-10-28 18:07:13'),
(864, 660042243, 6, 6, '2011-10-28 18:08:31'),
(865, 660042243, 2, 6, '2011-10-28 18:09:25'),
(866, 660042243, 10, 6, '2011-10-28 18:10:13'),
(867, 660042243, 9, 6, '2011-10-28 18:10:22'),
(868, 660042243, 13, 6, '2011-10-28 18:10:45'),
(869, 660042243, 6, 6, '2011-10-28 18:12:38'),
(870, 660042243, 2, 6, '2011-10-28 18:15:20'),
(871, 660042243, 2, 6, '2011-10-28 18:49:25'),
(872, 660042243, 13, 6, '2011-10-28 18:49:32'),
(873, 660042243, 2, 6, '2011-10-28 18:50:13'),
(874, 660042243, 6, 6, '2011-10-28 18:50:41'),
(875, 660042243, 9, 6, '2011-10-28 19:19:58'),
(876, 660042243, 10, 6, '2011-10-28 19:20:15'),
(877, 660042243, 4, 6, '2011-10-28 21:19:57'),
(878, 660042243, 2, 6, '2011-10-29 10:52:21'),
(879, 660042243, 11, 6, '2011-10-29 12:11:29'),
(880, 660042243, 10, 6, '2011-10-29 13:23:27'),
(881, 660042243, 11, 6, '2011-10-29 13:40:16'),
(882, 660042243, 10, 6, '2011-10-29 13:58:14'),
(883, 660042243, 2, 6, '2011-10-29 13:59:01'),
(884, 660042243, 9, 6, '2011-10-29 13:59:58'),
(885, 660042243, 10, 6, '2011-10-29 14:00:41'),
(886, 660042243, 2, 6, '2011-10-29 14:02:48'),
(887, 660042243, 2, 6, '2011-10-29 14:03:04'),
(888, 660042243, 10, 6, '2011-10-29 14:04:05'),
(889, 660042243, 9, 6, '2011-10-29 14:04:39'),
(890, 660042243, 10, 6, '2011-10-29 14:05:21'),
(891, 660042243, 10, 6, '2011-10-29 14:05:53'),
(892, 660042243, 11, 6, '2011-10-29 14:08:13'),
(893, 660042243, 10, 6, '2011-10-29 14:10:36'),
(894, 660042243, 12, 6, '2011-10-29 14:12:22'),
(895, 660042243, 6, 6, '2011-10-29 14:12:49'),
(896, 660042243, 10, 6, '2011-10-29 14:13:31'),
(897, 660042243, 6, 6, '2011-10-29 14:14:20'),
(898, 660042243, 10, 6, '2011-10-29 14:35:35'),
(899, 660042243, 10, 6, '2011-10-29 14:36:04'),
(900, 660042243, 10, 6, '2011-10-29 14:36:40'),
(901, 660042243, 10, 6, '2011-10-29 14:37:37'),
(902, 660042243, 10, 6, '2011-10-29 14:38:56'),
(903, 660042243, 6, 6, '2011-10-29 14:40:01'),
(904, 660042243, 11, 6, '2011-10-29 14:40:35'),
(905, 660042243, 10, 6, '2011-10-29 14:41:10'),
(906, 660042243, 11, 6, '2011-10-29 14:41:58'),
(907, 660042243, 9, 6, '2011-10-29 14:43:42'),
(908, 660042243, 11, 6, '2011-10-29 14:44:34'),
(909, 660042243, 10, 6, '2011-10-29 14:45:12'),
(910, 660042243, 11, 6, '2011-10-29 14:45:30'),
(911, 660042243, 4, 6, '2011-10-29 14:45:50'),
(912, 660042243, 12, 6, '2011-10-29 14:47:05'),
(913, 660042243, 11, 6, '2011-10-29 14:51:28'),
(914, 660042243, 10, 6, '2011-10-29 14:54:20'),
(915, 660042243, 6, 6, '2011-10-29 14:54:50'),
(916, 660042243, 10, 6, '2011-10-29 14:56:27'),
(917, 660042243, 6, 6, '2011-10-29 14:57:50'),
(918, 660042243, 6, 6, '2011-10-29 14:59:04'),
(919, 660042243, 10, 6, '2011-10-29 15:01:36'),
(920, 660042243, 10, 6, '2011-10-29 15:03:18'),
(921, 660042243, 6, 6, '2011-10-29 15:03:48'),
(922, 660042243, 2, 6, '2011-10-29 16:59:07'),
(923, 660042243, 6, 6, '2011-10-29 16:59:58'),
(924, 660042243, 4, 6, '2011-10-29 17:00:39'),
(925, 660042243, 11, 6, '2011-10-29 17:00:57'),
(926, 660042243, 4, 6, '2011-10-29 17:01:15'),
(927, 660042243, 4, 6, '2011-10-29 18:54:08'),
(928, 660042243, 2, 6, '2011-10-29 18:54:49'),
(929, 660042243, 11, 6, '2011-10-29 18:57:19'),
(930, 660042243, 10, 6, '2011-10-29 18:57:46'),
(931, 660042243, 6, 6, '2011-10-29 19:20:56'),
(932, 660042243, 4, 6, '2011-10-29 19:21:00'),
(933, 660042243, 5, 6, '2011-10-29 19:39:03'),
(934, 660042243, 5, 6, '2011-10-29 19:39:14'),
(935, 660042243, 5, 6, '2011-10-29 19:43:34'),
(936, 660042243, 14, 6, '2011-10-29 19:49:19'),
(937, 660042243, 8, 6, '2011-10-29 19:49:40'),
(938, 660042243, 7, 6, '2011-10-29 19:50:31'),
(939, 660042243, 2, 6, '2011-10-29 20:10:05'),
(940, 660042243, 11, 6, '2011-10-29 20:10:18'),
(941, 660042243, 4, 6, '2011-10-29 20:20:37'),
(942, 660042243, 4, 6, '2011-10-29 20:23:30'),
(943, 660042243, 14, 6, '2011-10-29 20:23:38'),
(944, 660042243, 10, 6, '2011-10-29 20:23:50'),
(945, 660042243, 2, 6, '2011-10-29 20:26:03'),
(946, 660042243, 10, 6, '2011-10-29 20:27:14'),
(947, 660042243, 2, 6, '2011-10-29 20:30:29'),
(948, 660042243, 9, 6, '2011-10-29 20:31:41'),
(949, 660042243, 4, 6, '2011-10-29 20:32:31'),
(950, 660042243, 10, 6, '2011-10-29 20:38:43'),
(951, 660042243, 7, 6, '2011-10-29 20:44:14'),
(952, 660042243, 14, 6, '2011-10-29 20:46:17'),
(953, 660042243, 4, 6, '2011-10-29 20:47:22'),
(954, 660042243, 10, 6, '2011-10-29 20:48:30'),
(955, 660042243, 14, 6, '2011-10-29 20:48:34'),
(956, 660042243, 14, 6, '2011-10-29 20:49:46'),
(957, 660042243, 10, 6, '2011-10-29 20:50:01'),
(958, 660042243, 6, 6, '2011-10-29 20:51:53'),
(959, 660042243, 5, 6, '2011-10-29 21:26:31'),
(960, 660042243, 9, 6, '2011-10-29 21:29:38'),
(961, 660042243, 10, 6, '2011-10-29 21:31:38'),
(962, 660042243, 14, 6, '2011-10-29 21:41:17'),
(963, 660042243, 11, 6, '2011-10-29 21:42:15'),
(964, 660042243, 6, 6, '2011-10-29 21:43:25'),
(965, 660042243, 9, 6, '2011-10-29 21:46:31'),
(966, 660042243, 6, 6, '2011-10-29 23:54:31'),
(967, 660042243, 10, 6, '2011-10-30 00:02:53'),
(968, 660042243, 5, 6, '2011-10-30 00:03:43'),
(969, 660042243, 4, 6, '2011-10-30 00:06:34'),
(970, 660042243, 5, 6, '2011-10-30 00:13:01'),
(971, 660042243, 8, 6, '2011-10-30 00:14:23'),
(972, 660042243, 7, 6, '2011-10-30 00:14:32'),
(973, 660042243, 12, 6, '2011-10-30 00:16:53'),
(974, 660042243, 9, 6, '2011-10-30 00:17:03'),
(975, 660042243, 7, 6, '2011-10-30 00:17:16'),
(976, 660042243, 10, 6, '2011-10-30 00:17:41'),
(977, 660042243, 7, 6, '2011-10-30 00:22:22'),
(978, 660042243, 8, 6, '2011-10-30 00:22:48'),
(979, 660042243, 6, 6, '2011-10-30 00:24:02'),
(980, 660042243, 9, 6, '2011-10-30 00:28:14'),
(981, 660042243, 5, 6, '2011-10-30 00:29:14'),
(982, 660042243, 2, 6, '2011-10-30 00:29:25'),
(983, 660042243, 4, 6, '2011-10-30 00:29:37'),
(984, 660042243, 10, 6, '2011-10-30 00:31:43'),
(985, 660042243, 2, 6, '2011-10-30 00:32:26'),
(986, 660042243, 14, 6, '2011-10-30 00:33:02'),
(987, 660042243, 4, 6, '2011-10-30 00:33:43'),
(988, 660042243, 9, 6, '2011-10-30 00:35:40'),
(989, 660042243, 11, 6, '2011-10-30 00:36:18'),
(990, 660042243, 5, 6, '2011-10-30 00:37:08'),
(991, 660042243, 12, 6, '2011-10-30 00:37:18'),
(992, 660042243, 2, 6, '2011-10-30 00:37:45'),
(993, 660042243, 5, 6, '2011-10-30 00:39:05'),
(994, 660042243, 10, 6, '2011-10-30 00:39:17'),
(995, 660042243, 9, 6, '2011-10-30 00:39:30'),
(996, 660042243, 13, 6, '2011-10-30 00:45:20'),
(997, 660042243, 4, 6, '2011-10-30 00:45:57'),
(998, 660042243, 9, 6, '2011-10-30 00:47:12'),
(999, 660042243, 2, 6, '2011-10-30 00:47:27'),
(1000, 660042243, 7, 6, '2011-10-30 00:49:00'),
(1001, 660042243, 8, 6, '2011-10-30 00:50:38'),
(1002, 660042243, 2, 6, '2011-10-30 00:53:03'),
(1003, 660042243, 7, 6, '2011-10-30 01:03:14'),
(1004, 660042243, 8, 6, '2011-10-30 01:05:01'),
(1005, 660042243, 2, 6, '2011-10-30 01:05:50'),
(1006, 660042243, 14, 6, '2011-10-30 01:07:53'),
(1007, 660042243, 10, 6, '2011-10-30 01:08:20'),
(1008, 660042243, 11, 6, '2011-10-30 01:08:54'),
(1009, 660042243, 5, 6, '2011-10-30 01:12:22'),
(1010, 660042243, 6, 6, '2011-10-30 01:23:38'),
(1011, 660042243, 14, 6, '2011-10-30 01:30:16'),
(1012, 660042243, 14, 6, '2011-10-30 01:33:41'),
(1013, 660042243, 9, 6, '2011-10-30 02:24:03'),
(1014, 660042243, 4, 6, '2011-10-30 02:24:13'),
(1015, 660042243, 6, 6, '2011-10-30 02:29:07'),
(1016, 660042243, 5, 6, '2011-10-30 02:29:52'),
(1017, 660042243, 11, 6, '2011-10-30 02:31:49'),
(1018, 660042243, 14, 6, '2011-10-30 02:31:58'),
(1019, 660042243, 11, 6, '2011-10-30 02:33:24'),
(1020, 660042243, 9, 6, '2011-10-30 02:50:01'),
(1021, 660042243, 12, 6, '2011-10-30 02:50:33'),
(1022, 660042243, 7, 6, '2011-10-30 02:50:47'),
(1023, 660042243, 8, 6, '2011-10-30 02:53:09'),
(1024, 660042243, 12, 6, '2011-10-30 02:53:55'),
(1025, 660042243, 11, 6, '2011-10-30 02:55:08'),
(1026, 660042243, 5, 6, '2011-10-30 02:56:50'),
(1027, 660042243, 4, 6, '2011-10-30 02:57:42'),
(1028, 660042243, 8, 6, '2011-10-30 02:57:52'),
(1029, 660042243, 11, 6, '2011-10-30 03:05:37'),
(1030, 660042243, 12, 6, '2011-10-30 03:07:32'),
(1031, 660042243, 14, 6, '2011-10-30 03:07:51'),
(1032, 660042243, 8, 6, '2011-10-30 03:12:44'),
(1033, 660042243, 6, 6, '2011-10-30 03:13:30'),
(1034, 660042243, 7, 6, '2011-10-30 03:22:54'),
(1035, 660042243, 9, 6, '2011-10-30 03:23:40'),
(1036, 660042243, 4, 6, '2011-10-30 03:25:21'),
(1037, 660042243, 6, 6, '2011-10-30 03:26:03'),
(1038, 660042243, 4, 6, '2011-10-30 03:27:02'),
(1039, 660042243, 11, 6, '2011-10-30 04:43:24'),
(1040, 660042243, 4, 6, '2011-10-30 05:34:59'),
(1041, 660042243, 13, 6, '2011-10-30 08:09:35'),
(1042, 660042243, 10, 6, '2011-10-30 08:10:04'),
(1043, 660042243, 6, 6, '2011-10-30 08:10:50'),
(1044, 660042243, 9, 6, '2011-10-30 08:11:34'),
(1045, 660042243, 7, 6, '2011-10-30 08:11:46'),
(1046, 660042243, 10, 6, '2011-10-30 08:13:38'),
(1047, 660042243, 7, 6, '2011-10-30 09:52:04'),
(1048, 660042243, 2, 6, '2011-10-30 10:43:02'),
(1049, 660042243, 10, 6, '2011-10-30 10:48:00'),
(1050, 660042243, 11, 6, '2011-10-30 12:02:01'),
(1051, 660042243, 9, 6, '2011-10-30 12:02:30'),
(1052, 660042243, 5, 6, '2011-10-30 12:07:10'),
(1053, 660042243, 10, 6, '2011-10-30 12:07:28'),
(1054, 660042243, 5, 6, '2011-10-30 12:07:43'),
(1055, 660042243, 10, 6, '2011-10-30 12:08:37'),
(1056, 660042243, 10, 6, '2011-10-30 12:08:58'),
(1057, 660042243, 5, 6, '2011-10-30 12:12:04'),
(1058, 660042243, 5, 6, '2011-10-30 12:12:41'),
(1059, 660042243, 5, 6, '2011-10-30 12:13:51'),
(1060, 660042243, 14, 6, '2011-10-30 12:52:28'),
(1061, 660042243, 2, 6, '2011-10-30 13:16:45'),
(1062, 660042243, 9, 6, '2011-10-30 13:36:52'),
(1063, 660042243, 5, 6, '2011-10-30 13:38:17'),
(1064, 660042243, 5, 6, '2011-10-30 13:39:05'),
(1065, 660042243, 5, 6, '2011-10-30 13:40:53'),
(1066, 660042243, 5, 6, '2011-10-30 13:42:24'),
(1067, 660042243, 11, 6, '2011-10-30 13:54:36'),
(1068, 660042243, 10, 6, '2011-10-30 13:55:24'),
(1069, 660042243, 2, 6, '2011-10-30 13:56:19'),
(1070, 660042243, 9, 6, '2011-10-30 13:57:20'),
(1071, 660042243, 14, 6, '2011-10-30 14:31:59'),
(1072, 660042243, 14, 6, '2011-10-30 14:42:54'),
(1073, 660042243, 14, 6, '2011-10-30 14:44:35'),
(1074, 660042243, 14, 6, '2011-10-30 14:52:56'),
(1075, 660042243, 7, 6, '2011-10-30 15:00:26'),
(1076, 660042243, 6, 6, '2011-10-30 15:04:57'),
(1077, 660042243, 5, 6, '2011-10-30 15:55:18'),
(1078, 660042243, 2, 6, '2011-10-30 15:56:14'),
(1079, 660042243, 5, 6, '2011-10-30 15:58:41'),
(1080, 660042243, 4, 6, '2011-10-30 15:58:59'),
(1081, 660042243, 6, 6, '2011-10-30 15:59:24'),
(1082, 660042243, 8, 6, '2011-10-30 15:59:35'),
(1083, 660042243, 13, 6, '2011-10-30 16:02:07'),
(1084, 660042243, 8, 6, '2011-10-30 16:02:23'),
(1085, 660042243, 7, 6, '2011-10-30 16:02:32'),
(1086, 660042243, 7, 6, '2011-10-30 16:05:18'),
(1087, 660042243, 13, 6, '2011-10-30 16:05:29'),
(1088, 660042243, 7, 6, '2011-10-30 16:06:39'),
(1089, 660042243, 13, 6, '2011-10-30 16:06:46'),
(1090, 660042243, 8, 6, '2011-10-30 16:07:31'),
(1091, 660042243, 13, 6, '2011-10-30 16:09:00'),
(1092, 660042243, 7, 6, '2011-10-30 16:09:07'),
(1093, 660042243, 7, 6, '2011-10-30 16:09:46'),
(1094, 660042243, 13, 6, '2011-10-30 16:09:49'),
(1095, 660042243, 8, 6, '2011-10-30 16:09:54'),
(1096, 660042243, 12, 6, '2011-10-30 16:09:58'),
(1097, 660042243, 5, 6, '2011-10-30 16:10:02'),
(1098, 660042243, 14, 6, '2011-10-30 16:13:18'),
(1099, 660042243, 4, 6, '2011-10-30 16:13:37'),
(1100, 660042243, 5, 6, '2011-10-30 16:15:02'),
(1101, 660042243, 5, 6, '2011-10-30 16:22:08'),
(1102, 660042243, 12, 6, '2011-10-30 16:25:05'),
(1103, 660042243, 4, 6, '2011-10-30 16:25:35'),
(1104, 660042243, 14, 6, '2011-10-30 16:26:48'),
(1105, 660042243, 13, 6, '2011-10-30 16:29:41'),
(1106, 660042243, 7, 6, '2011-10-30 16:30:26'),
(1107, 660042243, 8, 6, '2011-10-30 16:30:30'),
(1108, 660042243, 13, 6, '2011-10-30 16:30:33'),
(1109, 660042243, 5, 6, '2011-10-30 16:30:35'),
(1110, 660042243, 14, 6, '2011-10-30 16:30:37'),
(1111, 660042243, 11, 6, '2011-10-30 16:30:39'),
(1112, 660042243, 2, 6, '2011-10-30 16:30:41'),
(1113, 660042243, 14, 6, '2011-10-30 17:41:48'),
(1114, 660042243, 4, 6, '2011-10-30 17:43:02'),
(1115, 660042243, 7, 6, '2011-10-30 17:44:14'),
(1116, 660042243, 2, 6, '2011-10-30 17:46:27'),
(1117, 660042243, 10, 6, '2011-10-30 17:49:42'),
(1118, 660042243, 11, 6, '2011-10-30 17:50:50'),
(1119, 660042243, 9, 6, '2011-10-30 18:07:21'),
(1120, 660042243, 5, 6, '2011-10-30 19:04:12'),
(1121, 660042243, 5, 6, '2011-10-30 19:05:16'),
(1122, 660042243, 11, 6, '2011-10-30 20:19:16'),
(1123, 660042243, 2, 6, '2011-10-30 20:19:21'),
(1124, 660042243, 12, 6, '2011-10-30 20:19:26'),
(1125, 660042243, 10, 6, '2011-10-30 20:19:32'),
(1126, 660042243, 1, 6, '2011-10-30 20:19:40'),
(1127, 660042243, 3, 6, '2011-10-30 20:21:58'),
(1128, 660042243, 5, 6, '2011-10-30 20:23:41'),
(1129, 660042243, 9, 6, '2011-10-30 20:23:46'),
(1130, 660042243, 3, 6, '2011-10-30 20:31:33'),
(1131, 660042243, 10, 6, '2011-10-30 20:34:29'),
(1132, 660042243, 7, 6, '2011-10-30 20:35:22'),
(1133, 660042243, 3, 6, '2011-10-30 20:36:22'),
(1134, 660042243, 12, 6, '2011-10-30 20:38:49'),
(1135, 660042243, 11, 6, '2011-10-30 20:39:50'),
(1136, 660042243, 1, 6, '2011-10-30 20:40:19'),
(1137, 660042243, 100, 6, '2011-10-30 21:32:00'),
(1138, 660042243, 100, 6, '2011-10-30 21:33:07'),
(1139, 660042243, 100, 6, '2011-10-30 21:41:09'),
(1140, 660042243, 101, 6, '2011-10-30 21:41:14'),
(1141, 660042243, 102, 6, '2011-10-30 21:41:19'),
(1142, 660042243, 102, 6, '2011-10-30 21:41:51'),
(1143, 660042243, 6, 6, '2011-10-30 22:05:41'),
(1144, 660042243, 6, 6, '2011-10-30 22:06:59'),
(1145, 660042243, 6, 6, '2011-10-30 22:09:08'),
(1146, 660042243, 6, 6, '2011-10-30 22:30:58'),
(1147, 660042243, 6, 6, '2011-10-30 22:31:58'),
(1148, 660042243, 6, 6, '2011-10-30 22:32:20'),
(1149, 660042243, 6, 6, '2011-10-30 22:33:00'),
(1150, 660042243, 6, 6, '2011-10-30 22:33:27'),
(1151, 660042243, 6, 6, '2011-10-30 22:33:53'),
(1152, 660042243, 6, 6, '2011-10-30 22:43:05'),
(1153, 660042243, 6, 6, '2011-10-30 22:50:19'),
(1154, 660042243, 6, 6, '2011-10-30 22:56:05'),
(1155, 660042243, 6, 6, '2011-10-30 22:57:43'),
(1156, 660042243, 5, 6, '2011-10-30 23:03:45'),
(1157, 660042243, 4, 6, '2011-10-30 23:08:56'),
(1158, 660042243, 4, 6, '2011-10-30 23:09:26'),
(1159, 660042243, 5, 6, '2011-10-30 23:09:43'),
(1160, 660042243, 6, 6, '2011-10-30 23:10:59'),
(1161, 660042243, 102, 6, '2011-10-30 23:14:55'),
(1162, 660042243, 4, 6, '2011-10-30 23:16:59'),
(1163, 660042243, 100, 6, '2011-10-30 23:17:19'),
(1164, 660042243, 6, 6, '2011-10-30 23:20:04'),
(1165, 660042243, 100, 6, '2011-10-30 23:23:22'),
(1166, 660042243, 101, 6, '2011-10-30 23:23:50'),
(1167, 660042243, 100, 6, '2011-10-30 23:24:32'),
(1168, 660042243, 102, 6, '2011-10-30 23:24:38'),
(1169, 660042243, 100, 6, '2011-10-30 23:24:49'),
(1170, 660042243, 102, 6, '2011-10-30 23:24:55'),
(1171, 660042243, 100, 6, '2011-10-30 23:29:31'),
(1172, 660042243, 100, 6, '2011-10-30 23:29:38'),
(1173, 660042243, 102, 6, '2011-10-30 23:33:07'),
(1174, 660042243, 1, 6, '2011-10-30 23:39:35'),
(1175, 660042243, 2, 6, '2011-10-30 23:40:15'),
(1176, 660042243, 3, 6, '2011-10-30 23:40:28'),
(1177, 660042243, 3, 6, '2011-10-30 23:41:48'),
(1178, 660042243, 4, 6, '2011-10-30 23:42:08'),
(1179, 660042243, 5, 6, '2011-10-30 23:42:53'),
(1180, 660042243, 6, 6, '2011-10-30 23:42:58'),
(1181, 660042243, 7, 6, '2011-10-30 23:43:06'),
(1182, 660042243, 8, 6, '2011-10-30 23:43:10'),
(1183, 660042243, 9, 6, '2011-10-30 23:43:14'),
(1184, 660042243, 10, 6, '2011-10-30 23:43:20'),
(1185, 660042243, 11, 6, '2011-10-30 23:43:25'),
(1186, 660042243, 12, 6, '2011-10-30 23:43:29'),
(1187, 660042243, 13, 6, '2011-10-30 23:43:33'),
(1188, 660042243, 14, 6, '2011-10-30 23:43:42'),
(1189, 660042243, 15, 6, '2011-10-30 23:43:51'),
(1190, 660042243, 16, 6, '2011-10-30 23:44:04'),
(1191, 660042243, 1, 6, '2011-10-30 23:44:28'),
(1192, 660042243, 1, 6, '2011-10-30 23:48:29'),
(1193, 660042243, 1, 6, '2011-10-30 23:49:58'),
(1194, 660042243, 2, 6, '2011-10-30 23:50:07'),
(1195, 660042243, 2, 6, '2011-10-30 23:51:18'),
(1196, 660042243, 1, 6, '2011-10-30 23:51:24'),
(1197, 660042243, 3, 6, '2011-10-30 23:51:51'),
(1198, 660042243, 3, 6, '2011-10-30 23:52:38'),
(1199, 660042243, 4, 6, '2011-10-30 23:53:02'),
(1200, 660042243, 5, 6, '2011-10-30 23:53:19'),
(1201, 660042243, 13, 6, '2011-10-30 23:53:26'),
(1202, 660042243, 13, 6, '2011-10-30 23:53:55'),
(1203, 660042243, 14, 6, '2011-10-30 23:54:06'),
(1204, 660042243, 15, 6, '2011-10-30 23:54:22'),
(1205, 660042243, 16, 6, '2011-10-30 23:54:45'),
(1206, 660042243, 2, 6, '2011-10-30 23:58:28'),
(1207, 660042243, 1, 6, '2011-10-31 00:03:42'),
(1208, 660042243, 2, 6, '2011-10-31 00:04:18'),
(1209, 660042243, 2, 6, '2011-10-31 00:05:43'),
(1210, 660042243, 2, 6, '2011-10-31 00:34:13'),
(1211, 660042243, 2, 6, '2011-10-31 00:35:50'),
(1212, 660042243, 2, 6, '2011-10-31 00:36:58'),
(1213, 660042243, 2, 6, '2011-10-31 00:37:32'),
(1214, 660042243, 2, 6, '2011-10-31 00:39:57'),
(1215, 660042243, 2, 6, '2011-10-31 00:40:59'),
(1216, 660042243, 2, 6, '2011-10-31 00:43:37'),
(1217, 660042243, 2, 6, '2011-10-31 00:44:18'),
(1218, 660042243, 2, 6, '2011-10-31 00:45:32'),
(1219, 660042243, 2, 6, '2011-10-31 00:46:37'),
(1220, 660042243, 2, 6, '2011-10-31 00:46:58'),
(1221, 660042243, 2, 6, '2011-10-31 00:47:48'),
(1222, 660042243, 2, 6, '2011-10-31 00:48:18'),
(1223, 660042243, 2, 6, '2011-10-31 00:49:06'),
(1224, 660042243, 2, 6, '2011-10-31 00:49:26'),
(1225, 660042243, 2, 6, '2011-10-31 00:49:51'),
(1226, 660042243, 2, 6, '2011-10-31 00:50:07'),
(1227, 660042243, 2, 6, '2011-10-31 00:50:37'),
(1228, 660042243, 2, 6, '2011-10-31 00:50:58'),
(1229, 660042243, 2, 6, '2011-10-31 00:51:17'),
(1230, 660042243, 2, 6, '2011-10-31 00:53:13'),
(1231, 660042243, 2, 6, '2011-10-31 00:53:54'),
(1232, 660042243, 2, 6, '2011-10-31 00:54:31'),
(1233, 660042243, 2, 6, '2011-10-31 00:55:08'),
(1234, 660042243, 2, 6, '2011-10-31 00:59:56'),
(1235, 660042243, 2, 6, '2011-10-31 01:01:55'),
(1236, 660042243, 2, 6, '2011-10-31 01:02:12'),
(1237, 660042243, 2, 6, '2011-10-31 01:02:31'),
(1238, 660042243, 2, 6, '2011-10-31 01:03:05'),
(1239, 660042243, 2, 6, '2011-10-31 01:03:16'),
(1240, 660042243, 2, 6, '2011-10-31 01:03:50'),
(1241, 660042243, 2, 6, '2011-10-31 01:06:50'),
(1242, 660042243, 2, 6, '2011-10-31 01:09:21'),
(1243, 660042243, 2, 6, '2011-10-31 01:11:47'),
(1244, 660042243, 2, 6, '2011-10-31 01:12:58'),
(1245, 660042243, 9, 6, '2011-10-31 01:19:06'),
(1246, 660042243, 4, 6, '2011-10-31 01:19:20'),
(1247, 660042243, 101, 6, '2011-10-31 01:19:35'),
(1248, 660042243, 10, 6, '2011-10-31 01:33:31'),
(1249, 660042243, 16, 6, '2011-10-31 01:33:43'),
(1250, 660042243, 4, 6, '2011-10-31 01:34:44'),
(1251, 660042243, 12, 6, '2011-10-31 01:36:34'),
(1252, 660042243, 14, 6, '2011-10-31 01:37:49'),
(1253, 660042243, 5, 6, '2011-10-31 08:09:32'),
(1254, 660042243, 5, 6, '2011-10-31 08:09:58'),
(1255, 660042243, 5, 6, '2011-10-31 08:11:09'),
(1256, 660042243, 5, 6, '2011-10-31 08:20:25'),
(1257, 660042243, 16, 6, '2011-10-31 08:20:38'),
(1258, 660042243, 2, 6, '2011-10-31 08:27:44'),
(1259, 660042243, 6, 6, '2011-10-31 08:29:31'),
(1260, 660042243, 12, 6, '2011-10-31 08:29:50'),
(1261, 660042243, 5, 6, '2011-10-31 08:35:19'),
(1262, 1554917948, 5, 6, '2011-10-31 08:37:16'),
(1263, 1554917948, 5, 6, '2011-10-31 08:39:48'),
(1264, 1554917948, 5, 6, '2011-10-31 08:40:10'),
(1265, 1554917948, 14, 6, '2011-10-31 08:40:22'),
(1266, 1554917948, 10, 6, '2011-10-31 08:44:21'),
(1267, 660042243, 2, 6, '2011-10-31 09:03:41'),
(1268, 660042243, 2, 6, '2011-10-31 09:05:41'),
(1269, 660042243, 2, 6, '2011-10-31 09:28:51'),
(1270, 660042243, 9, 6, '2011-10-31 09:29:32'),
(1271, 1554917948, 9, 6, '2011-10-31 09:29:47'),
(1272, 660042243, 12, 6, '2011-10-31 09:34:09'),
(1273, 660042243, 102, 6, '2011-10-31 09:35:10'),
(1274, 660042243, 6, 6, '2011-10-31 10:26:44'),
(1275, 660042243, 6, 6, '2011-10-31 10:29:37'),
(1276, 660042243, 6, 6, '2011-10-31 10:32:20'),
(1277, 660042243, 6, 6, '2011-10-31 10:39:52'),
(1278, 660042243, 6, 6, '2011-10-31 10:43:16'),
(1279, 660042243, 6, 6, '2011-10-31 10:44:03'),
(1280, 660042243, 2, 6, '2011-10-31 11:33:17'),
(1281, 660042243, 10, 6, '2011-10-31 12:20:51'),
(1282, 660042243, 6, 6, '2011-10-31 12:58:25'),
(1283, 660042243, 9, 6, '2011-10-31 12:59:00'),
(1284, 660042243, 100, 6, '2011-10-31 17:25:57'),
(1285, 660042243, 5, 6, '2011-10-31 19:20:42'),
(1286, 1390251585, 8, 6, '2011-10-31 19:21:21'),
(1287, 1390251585, 100, 6, '2011-10-31 19:21:43'),
(1288, 1390251585, 102, 6, '2011-10-31 19:21:48'),
(1289, 1390251585, 100, 6, '2011-10-31 19:21:52'),
(1290, 1390251585, 10, 6, '2011-10-31 19:22:26'),
(1291, 660042243, 10, 6, '2011-10-31 20:35:19'),
(1292, 1390251585, 5, 6, '2011-10-31 20:40:53'),
(1293, 1390251585, 10, 6, '2011-10-31 20:41:01'),
(1294, 1390251585, 6, 6, '2011-10-31 20:41:23'),
(1295, 1390251585, 9, 6, '2011-10-31 20:42:37'),
(1296, 1390251585, 2, 6, '2011-10-31 20:43:01'),
(1297, 660042243, 10, 6, '2011-10-31 20:45:26'),
(1298, 1390251585, 12, 6, '2011-10-31 21:21:28'),
(1299, 660042243, 2, 6, '2011-11-01 08:50:05'),
(1300, 660042243, 9, 6, '2011-11-01 08:53:23');
INSERT INTO `tblUsersJobs` (`id`, `user_id`, `job_id`, `status_id`, `added`) VALUES
(1301, 660042243, 2, 6, '2011-11-01 08:53:39'),
(1302, 660042243, 2, 6, '2011-11-01 08:55:23'),
(1303, 660042243, 2, 6, '2011-11-01 12:47:49'),
(1304, 660042243, 2, 6, '2011-11-01 16:20:18'),
(1305, 660042243, 3, 6, '2011-11-01 16:20:34'),
(1306, 660042243, 4, 6, '2011-11-01 16:20:39'),
(1307, 660042243, 5, 6, '2011-11-01 16:20:46'),
(1308, 660042243, 6, 6, '2011-11-01 16:20:58'),
(1309, 660042243, 8, 6, '2011-11-01 16:21:03'),
(1310, 660042243, 9, 6, '2011-11-01 16:49:10'),
(1311, 660042243, 10, 6, '2011-11-01 16:49:17'),
(1312, 660042243, 11, 6, '2011-11-01 16:49:23'),
(1313, 660042243, 12, 6, '2011-11-01 16:49:29'),
(1314, 660042243, 13, 6, '2011-11-01 17:45:01'),
(1315, 660042243, 14, 6, '2011-11-01 17:45:20'),
(1316, 660042243, 2, 6, '2011-11-03 17:05:47'),
(1317, 660042243, 6, 6, '2011-11-03 17:08:54'),
(1318, 1390251585, 6, 6, '2011-11-03 18:55:43'),
(1319, 1390251585, 9, 6, '2011-11-03 18:56:55'),
(1320, 1390251585, 12, 6, '2011-11-03 18:57:21'),
(1321, 1390251585, 5, 6, '2011-11-03 18:59:05'),
(1322, 1390251585, 100, 6, '2011-11-03 18:59:26'),
(1323, 1390251585, 8, 6, '2011-11-03 19:00:12'),
(1324, 660042243, 6, 6, '2011-11-07 14:38:23'),
(1325, 660042243, 6, 6, '2011-11-07 14:39:04'),
(1326, 660042243, 5, 6, '2011-11-07 15:04:12'),
(1327, 660042243, 5, 6, '2011-11-07 15:05:32'),
(1328, 660042243, 10, 6, '2011-11-07 15:07:20'),
(1329, 660042243, 9, 6, '2011-11-07 15:08:45'),
(1330, 660042243, 12, 6, '2011-11-07 15:10:47'),
(1331, 660042243, 2, 6, '2011-11-07 15:42:12'),
(1332, 660042243, 5, 6, '2011-11-07 16:01:27'),
(1333, 660042243, 10, 6, '2011-11-07 16:05:37'),
(1334, 660042243, 8, 6, '2011-11-07 16:05:44'),
(1335, 660042243, 100, 6, '2011-11-07 16:23:26'),
(1336, 660042243, 101, 6, '2011-11-07 16:23:30'),
(1337, 660042243, 102, 6, '2011-11-07 16:23:34'),
(1338, 660042243, 2, 6, '2011-11-07 16:23:38'),
(1339, 660042243, 5, 6, '2011-11-07 16:23:46'),
(1340, 660042243, 100, 6, '2011-11-07 16:25:37'),
(1341, 660042243, 12, 6, '2011-11-07 16:26:33'),
(1342, 660042243, 6, 6, '2011-11-09 14:56:34'),
(1343, 660042243, 3, 6, '2011-11-09 14:56:52'),
(1344, 660042243, 11, 6, '2011-11-09 14:57:18'),
(1345, 660042243, 11, 6, '2011-11-09 14:57:40'),
(1346, 660042243, 11, 6, '2011-11-09 14:58:59'),
(1347, 660042243, 5, 6, '2011-11-09 15:00:17'),
(1348, 660042243, 1, 6, '2011-11-09 15:12:50'),
(1349, 660042243, 2, 6, '2011-11-09 15:13:02'),
(1350, 660042243, 4, 6, '2011-11-09 15:13:14'),
(1351, 660042243, 6, 6, '2011-11-09 15:13:34'),
(1352, 660042243, 6, 6, '2011-11-09 15:16:16'),
(1353, 660042243, 5, 6, '2011-11-09 15:16:37'),
(1354, 660042243, 5, 6, '2011-11-09 15:53:24'),
(1355, 660042243, 5, 6, '2011-11-09 15:53:30'),
(1356, 660042243, 5, 6, '2011-11-09 15:53:36'),
(1357, 1390251585, 6, 6, '2011-11-11 18:18:59'),
(1358, 1390251585, 5, 6, '2011-11-11 18:19:30'),
(1359, 660042243, 6, 6, '2011-11-22 15:21:55'),
(1360, 660042243, 2, 6, '2011-11-22 15:22:23'),
(1361, 660042243, 3, 6, '2011-11-22 15:23:26'),
(1362, 660042243, 4, 6, '2011-11-22 15:23:45'),
(1363, 660042243, 5, 6, '2011-11-22 15:23:50'),
(1364, 660042243, 6, 6, '2011-11-22 15:23:56'),
(1365, 660042243, 7, 6, '2011-11-22 15:24:02'),
(1366, 660042243, 8, 6, '2011-11-22 15:24:08'),
(1367, 660042243, 8, 6, '2011-11-22 15:39:48'),
(1368, 660042243, 2, 6, '2011-11-22 15:39:55'),
(1369, 660042243, 5, 6, '2011-11-22 15:40:07'),
(1370, 660042243, 7, 6, '2011-11-22 15:40:15'),
(1371, 660042243, 10, 6, '2011-11-22 15:40:35'),
(1372, 660042243, 12, 6, '2011-11-22 15:40:46'),
(1373, 660042243, 14, 6, '2011-11-22 15:40:56'),
(1374, 0, 100, 6, '2011-12-06 23:09:32'),
(1375, 660042243, 100, 6, '2011-12-06 23:10:12'),
(1376, 660042243, 100, 6, '2011-12-06 23:10:19'),
(1377, 660042243, 100, 6, '2011-12-06 23:11:00'),
(1378, 660042243, 100, 6, '2011-12-06 23:11:07'),
(1379, 660042243, 101, 6, '2011-12-06 23:11:20'),
(1380, 660042243, 2, 6, '2011-12-06 23:13:33'),
(1381, 660042243, 3, 6, '2011-12-06 23:14:08'),
(1382, 660042243, 5, 6, '2011-12-06 23:14:17'),
(1383, 660042243, 4, 6, '2011-12-12 18:30:56'),
(1384, 660042243, 1, 6, '2011-12-13 17:46:50'),
(1385, 660042243, 6, 6, '2011-12-13 17:59:27'),
(1386, 660042243, 100, 6, '2011-12-13 17:59:37'),
(1387, 660042243, 3, 6, '2011-12-13 17:59:52'),
(1388, 660042243, 1, 6, '2011-12-13 18:01:00'),
(1389, 660042243, 2, 6, '2011-12-13 18:05:11'),
(1390, 660042243, 100, 6, '2011-12-13 18:11:40'),
(1391, 660042243, 7, 6, '2011-12-13 18:13:22'),
(1392, 660042243, 6, 6, '2011-12-13 18:20:25'),
(1393, 660042243, 4, 6, '2011-12-13 19:11:48');
